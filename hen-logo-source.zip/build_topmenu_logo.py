"""Replace only the reviewed top-menu DDS texture; never execute the payload."""
from pathlib import Path
import argparse,json,struct,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import goldhen_tool as tool
START,END=0x6cc80,0x82270
BASE_SHA='52cdd17e264da7021d048debf04da49b40207e0171c7aaf0a126d8f4af388cbf'

def build(base,template,texture):
 if tool.sha256(base).hex()!=BASE_SHA:raise ValueError('Expected menu-branding-2 baseline')
 tool.require_original(template)
 core,_,_=tool.recover(base)
 old=core[START:END]
 if len(texture)!=len(old) or texture[:128]!=old[:128]:raise ValueError('DDS layout/header changed')
 if old[:4]!=b'DDS ' or old[84:88]!=b'DXT5':raise ValueError('Expected DXT5 texture')
 if struct.unpack_from('<I',core,END)[0]!=END-START:raise ValueError('DDS size field differs')
 if struct.unpack_from('<III',old,12)!=(256,256,65536) or struct.unpack_from('<I',old,28)[0]!=9:raise ValueError('Expected 256x256 and nine mipmaps')
 edited=core[:START]+texture+core[END:]
 changed=[i for i,(a,b) in enumerate(zip(core,edited)) if a!=b]
 if not changed or any(not START+128<=i<END for i in changed):raise ValueError('Changes escaped DDS data')
 if edited[:START]!=core[:START] or edited[END:]!=core[END:]:raise ValueError('Other core bytes changed')
 payload,receipt=tool.rebuild(template,edited)
 recovered,_,_=tool.recover(payload)
 if recovered!=edited:raise ValueError('Repack/decode mismatch')
 receipt.update(personal_revision='top-menu-logo-3',previous_payload_sha256=BASE_SHA,
  texture_start=hex(START),texture_end_exclusive=hex(END),texture_size=len(texture),
  texture_sha256=tool.sha256(texture).hex(),texture_format='DXT5',dimensions=[256,256],mipmaps=9,
  changed_core_bytes=len(changed),only_texture_data_changed=True,dds_header_and_size_field_preserved=True,
  executable_code_and_helpers_preserved=True,menu_text_settings_icon_and_startup_preserved=True,
  original_credits_preserved=True,payload_executed=False,console_tested=False)
 return payload,receipt

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--base',type=Path,default=ROOT/'baseline/XXFHen.bin')
 p.add_argument('--template',type=Path,default=ROOT/'baseline/goldhen.bin')
 p.add_argument('--texture',type=Path,default=ROOT/'xxfhen-top-menu.dds')
 p.add_argument('--output',type=Path,required=True)
 a=p.parse_args(); payload,receipt=build(a.base.read_bytes(),a.template.read_bytes(),a.texture.read_bytes())
 report=a.output.with_name(a.output.name+'.json')
 if a.output.exists() or report.exists():raise SystemExit('Choose new output paths')
 tool.write_new(a.output,payload);tool.write_new(report,(json.dumps(receipt,indent=2)+'\n').encode())
 print(json.dumps(receipt))
