# XXFHen top-menu logo update

Revision `top-menu-logo-3` replaces the yellow GoldHEN artwork in the PS4 top bar with the existing mint XF logo. It follows menu-branding-2 and retains its six personalized menu headings, settings icon, startup message and original credits.

The logo was a separate DDS resource at decoded-core offsets 0x6cc80–0x82270. Only its texture data changes: the original header, 256x256 size, DXT5 encoding, all nine mipmaps, 87,536-byte allocation and stored length are retained. No executable instructions, UI hooks, filesystem paths or other resources are patched.

`XXFHen.bin` is the new candidate; `baseline/XXFHen.bin` is menu build 2 for rollback. The original template is `baseline/goldhen.bin`. `top-menu-preview.png` is decoded from the actual replacement DDS. `verification.json` contains static checks. This is a texture-only binary customization, not recovered original GoldHEN source.

To reproduce the payload from the included DDS, use Python 3.10+: `python build_topmenu_logo.py --output rebuilt/XXFHen.bin`. The builder uses only the standard library. The DDS was encoded from the supplied logo with Pillow DXT5, one mip level at a time, and the original header preserved. The output was unpacked again and compared exactly; the payload was never executed here. Console testing remains pending.
