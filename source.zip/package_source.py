"""Package the published online-only XXFHen host's complete source download."""
from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parent
dist = root/'dist'
# Host source is intentionally public. Exclude hosting account identity,
# VCS internals, runtime state, and this archive to avoid recursive copies.
with zipfile.ZipFile(dist/'source.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(root.rglob('*')):
        relative = path.relative_to(root)
        if not path.is_file() or any(part.startswith('.') or part in ('node_modules','__pycache__') for part in relative.parts):
            continue
        if relative.as_posix() == 'dist/source.zip':
            continue
        z.write(path,relative.as_posix())
with zipfile.ZipFile(dist/'source.zip') as z:
    if z.testzip() is not None:
        raise ValueError('Source archive checksum failure')
print(json.dumps({'online_only':True,'source_zip_bytes':(dist/'source.zip').stat().st_size}))
