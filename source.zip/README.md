# XXFHen PS4 host

Static browser host for firmware 14.00. The default XXFHen flow uses Afterglow's original raw GoldHEN loader with the user's display-only v2.4b18.13 build. The separate reference route preserves the Sentrix host's original HEN wrapper.

Open the site in a PS4 browser on 14.00 and explicitly select Start. Desktop and other firmware browsers do not import loader modules. Both flows require an internet connection. The published hosting service does not support the legacy AppCache MIME type, so this build does not enable offline caching.

`dist/credits.html`, `dist/provenance.json`, `dist/licenses/`, and `upstream-notices/` retain original authorship and source references. The JavaScript engines and firmware patches are unchanged. No PS4 runtime test was performed.

After changing assets, run `python package_source.py` and redeploy the matching source.
