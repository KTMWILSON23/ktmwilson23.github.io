# XXFHen bundled OrbisFTP native writer build D6

D6 embeds the OrbisFTP server and libjbc in the HEN payload. It does not install a PKG, register a title, or require the OrbisFTP app. The webhost only delivers the payload.

## What changed

The owner's PS4 loaded D5 but its managed `ZipFile.ExtractToDirectory` call failed. The retained ZIP was 45,597 bytes, SHA-256 `87611af87890b6c5d39c5af5ec4a00a7cf616dc35753e5e745f334270be7f479`, and matched the embedded archive exactly. Both ZIP entries passed a local integrity check. D6 bypasses that managed extraction path: a bounded 295-byte native LZ4 decoder expands the bundled server and libjbc in scratch memory, and native file writes create `/user/data/XXFHen/oftp.bin` and `/user/data/XXFHen/jbc.sprx` directly. The old D5 diagnostic ZIP is removed by D6. The OrbisFTP server still uses its original startup logic, including filesystem remount attempts. Its library path is changed to `/user/data/XXFHen/jbc.sprx`.

The menu reads **Start OrbisFTP [D6]**. It probes port 1337, resolves the ShellUI parent AppId and process launch export, writes the two runtime files, then requests a ShellUI child process. A positive launch result only means the process service accepted the request; it does not prove FTP startup. No console process launch or FTP connection has yet been confirmed for D6.

## Validation

48 emulator cases across two relocation bases execute the actual menu registration, dispatch, native LZ4 decoder, native file writer, and process launch request. They check short and failed writes, damaged compressed data, port collision, missing interfaces, module search, launch errors, and preservation of existing menu actions. Two separate emulator cases execute the original outer payload SHA/authentication, ChaCha, and inflater instructions and compare all 638,712 decoded bytes. Two isolated checks previously verified the firmware 14.00 process-launch wrapper argument mapping. These checks cannot establish console runtime compatibility.

The payload is 330,264 bytes. The native callback and 54,310-byte LZ4 bundle fit in space reclaimed from the original top-menu DDS while preserving the mint XF logo using its 128×128 mip. Original GoldHEN menu and system credits remain. The previously working installed-app shortcut is included as `xxfhen-previous.bin` for rollback, although that shortcut needs the separate app installed.

## Rebuild

Install `source/requirements.txt` with Python 3, then run `source/build_embedded_orbis_d6.py` and `source/test_embedded_orbis_d6.py`. To validate the outer loader, run `python source/test_expanded_envelope.py source/build/xxfhen.bin source/build/native-envelope-checks.json`. The package includes the builder, tests, baseline binaries, and upstream OrbisFTP server source and binaries. It does not include the installer, Sony system libraries, or original complete GoldHEN C/C++ sources.

GoldHEN by SiSTRo and original contributors. OrbisFTP by OSM-Made. See `source/UPSTREAM.md`.
