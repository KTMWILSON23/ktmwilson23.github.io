# XXFHen bundled OrbisFTP executable-permission build D7

D7 embeds the OrbisFTP server and libjbc in the HEN payload. It does not install a PKG, register a title, or require the OrbisFTP app. The webhost only delivers the payload.

## What changed

The owner's PS4 loaded D6, and its native LZ4 decoder wrote both runtime files at the expected sizes. The launch service returned `0x8002000d` (access denied). Read-only GoldHEN FTP inspection showed `/user/data/XXFHen/oftp.bin` and `jbc.sprx` owned by root with mode `0600`; the executable had no execute bit. D7 creates these two files with mode `0755` so the launch service can read and execute them. It first removes the two files owned by XXFHen, then recreates them. The runtime directory remains under `/user/data/XXFHen`. This corrects an observed permissions fault, but the complete OrbisFTP launch is still awaiting a console test.

The menu reads **Start OrbisFTP [D7]**. It probes port 1337, resolves the ShellUI parent AppId and process launch export, decodes the bundled server and libjbc using a bounded native LZ4 decoder, writes the two runtime files, then requests a ShellUI child process. A positive launch result only means the process service accepted the request; it does not prove FTP startup.

## Validation

48 emulator cases across two relocation bases execute the actual menu registration, dispatch, native decoder, file writer, and process launch request. They check the `0755` creation mode, short and failed writes, damaged compressed data, port collision, missing interfaces, module search, launch errors, and preservation of existing menu actions. Two separate emulator cases execute the original outer payload SHA/authentication, ChaCha, and inflater instructions and compare all 638,712 decoded bytes. Two isolated checks previously verified the firmware 14.00 process-launch wrapper argument mapping. These checks cannot establish console runtime compatibility.

The payload is 330,264 bytes. The native callback and 54,310-byte LZ4 bundle fit in space reclaimed from the original top-menu DDS while preserving the mint XF logo using its 128×128 mip. Original GoldHEN credits remain. The previously working installed-app shortcut is included as `xxfhen-previous.bin` for rollback, although that shortcut needs the separate app installed.

## Rebuild

Install `source/requirements.txt` with Python 3, then run `source/build_embedded_orbis_d7.py` and `source/test_embedded_orbis_d7.py`. To validate the outer loader, run `python source/test_expanded_envelope.py source/build/xxfhen.bin source/build/native-envelope-checks.json`. The package includes the builder, tests, baseline binaries, and upstream OrbisFTP server source and binaries. It does not include the installer, Sony system libraries, or original complete GoldHEN C/C++ sources.

GoldHEN by SiSTRo and original contributors. OrbisFTP by OSM-Made. See `source/UPSTREAM.md`.
