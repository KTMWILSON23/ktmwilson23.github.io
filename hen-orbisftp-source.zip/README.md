# XXFHen bundled OrbisFTP diagnostic build 2

This candidate embeds the actual OrbisFTP server SELF and libjbc inside xxfhen.bin. It does not install a PKG or require an installed OrbisFTP title. The webhost only delivers the binary; the embedded menu callback prepares its bundled runtime files and starts the server.

**Live PS4 process creation and FTP startup have NOT been tested.** The previously working installed-app shortcut is supplied as xxfhen-previous.bin. This larger format changes the outer loader data layout as well as the menu action; it remains an experimental binary patch, not a recovered full GoldHEN source build.

## Runtime behavior

Select XXFHen Network > Start OrbisFTP. The callback first probes TCP port 1337 and checks the required runtime methods. If available, it writes an embedded archive temporarily to /data/xxfhen-orbisftp-runtime.zip, extracts only oftp.bin and jbc.sprx under /data/XXFHen, removes the archive, and requests sceSystemServiceAddLocalProcess with ShellUI as parent. It does not launch OFTP00001 or install/register a title. The original server's library path is changed to /data/XXFHen/jbc.sprx. All bytes originate in the HEN binary; there is no network download of server code.

`Bundled server launch requested` means the process service returned a positive process ID; it does not prove the FTP server completed startup. `Port 1337 is already in use` prevents competing servers, but does not identify the process already using it. Errors are shown separately for missing interfaces, parent ID, writes, extraction and process launch. The child process is associated with ShellUI and can end when that parent restarts.

The bundled OrbisFTP server retains upstream startup behavior, including filesystem remount attempts and its FTP commands. This is not an in-memory-only server: the two runtime files remain under /data/XXFHen for the process/library loader. No installer, SFO, app registration, or /system file installation is supplied.

## First console check

Fully restart (not Rest Mode), load this candidate, then select Start OrbisFTP. Do not start the installed OrbisFTP beforehand, because both use port 1337. Confirm an FTP connection on 1337 after the menu reports the launch request. An installed copy may remain present; this callback does not use it. To verify operation on a console that never installed OrbisFTP requires a separate console test. To roll back, fully restart and load xxfhen-previous.bin.

## Validation and layout

52 backend emulation cases pass across two relocation bases, executing the real existing menu registration routine and OnPress dispatcher. PS4 process, Mono and filesystem APIs are modeled. Cases cover short writes, cleanup, port collision, missing interfaces, managed exceptions, process errors, zero process ID and preservation of unrelated actions. These tests prove modeled control flow and ABI, not live service support.

Two tests execute the actual original outer SHA/authentication/ChaCha/decompression instructions in an isolated x86 emulator, with only kernel allocation/memcpy substituted. They compare all 638,712 decoded bytes and stop before running the HEN. A DEFLATE rewriter replaces stored blocks with fixed-Huffman blocks; 30 independent zlib-reference vectors were checked. The loader's data/BSS moves by 32,768 bytes, with 144 RIP references and five relative inflater switch entries adjusted. Prefix instruction sizes/control flow remain unchanged. The resulting payload is 330,264 bytes.

The native backend and 45,594-byte ZIP occupy space reclaimed from the top-menu DDS. The same XF logo uses its existing 128x128 mip with eight levels; its logical texture length is 22,000 bytes. Other component offsets, the core size and existing settings remain fixed. The obsolete installed-app callback is removed from the settings PNG's private chunk; image pixels/palette are preserved.

## Rebuild

Install source/requirements.txt with Python 3, then run source/build_embedded_orbis_diagnostic.py and source/test_embedded_orbis_diagnostic.py. To exercise the native outer decoder, from source run: python test_expanded_envelope.py build/xxfhen.bin build/native-envelope-checks.json. Outputs go under source/build. The included baseline binaries and original OrbisFTP binaries make the patch reproducible. No Sony system assembly or private console data is included.

GoldHEN by SiSTRo and original contributors. OrbisFTP by OSM-Made. See source/UPSTREAM.md. This source package contains the customization builder/tests plus the upstream OrbisFTP server sources, not original GoldHEN C/C++ sources.

## Diagnostic revision

The first embedded build loaded on the owner console but returned a generic interface-unavailable error before runtime-file creation. This revision changes the preflight guards to individual OF01 through OF10 messages. OF01, OF09 and OF10 include the raw system error in hexadecimal. The backend startup is still unverified; these diagnostics identify the failed stage rather than claiming a repair.
