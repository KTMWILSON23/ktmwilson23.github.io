
 .byte 0xf3,0x0f,0x1e,0xfa
 push rbx
 lea rbx, [rip]
 sub rbx, 387604
 lea rax, [rbx + 40240]; call rax
 lea rdi, [rbx + 391688]
 lea rsi, [rbx + 387720]
 xor edx, edx
 xor ecx, ecx
 lea rax, [rbx + 40240]; call rax
 pop rbx
 ret
 

.byte 0xf3,0x0f,0x1e,0xfa
 push rbx
 push rbp
 push r12
 push r13
 push r14
 push r15
 sub rsp, 0x180b8
 lea rbx, [rip]
 
 sub rbx, 387748
 mov r12, rsi
 mov qword ptr [rsp + 0x18], 0
 mov qword ptr [rsp + 0x20], 0
 mov qword ptr [rsp + 0x40], 0

 /* Briefly bind 1337 without listening; do not launch a competing server. */
 mov esi, 2
 mov edx, 1
 xor ecx, ecx
 mov edi, 97; xor eax, eax; lea rax, [rbx + 71538]; call rax
 jc socket_failed
 test eax, eax
 js socket_failed
 mov r13, rax
 mov qword ptr [rsp], 0x39050210
 mov qword ptr [rsp + 8], 0
 mov rsi, r13
 mov rdx, rsp
 mov ecx, 16
 mov edi, 104; xor eax, eax; lea rax, [rbx + 71538]; call rax
 setc r15b
 mov rsi, r13
 mov edi, 6; xor eax, eax; lea rax, [rbx + 71538]; call rax
 test r15b, r15b
 jnz port_busy

 mov rdi, [rbx + 0x76ad0]
 test rdi, rdi
 jz lnc_image_failed
 lea rsi, [rbx + 391707]
 lea rdx, [rbx + 391727]
 lea rax, [rbx + 42618]; call rax
 test rax, rax
 jz lnc_class_failed
 mov rsi, rax
 mov rdi, [rbx + 0x76ad0]
 lea rdx, [rbx + 391735]
 mov ecx, 1
 lea rax, [rbx + 43223]; call rax
 test rax, rax
 jz appid_method_failed
 mov rbp, rax
 lea rdi, [rbx + 391744]
 xor eax, eax
 lea rax, [rbx + 42682]; call rax
 test rax, rax
 jz title_failed
 mov rdi, rax
 call rbp
 test eax, eax
 jle parent_failed
 mov [rsp + 0x28], eax

 /* Find the export in existing modules; do not load a library by path. */
 mov qword ptr [rsp + 0x50], 0
 lea rsi, [rsp + 0xb0]
 mov edx, 256
 lea rcx, [rsp + 0x50]
 mov edi, 592; xor eax, eax; lea rax, [rbx + 71538]; call rax
 jc service_load_failed
 test eax, eax
 js service_load_failed
 cmp qword ptr [rsp + 0x50], 256
 ja module_count_failed
 mov r14d, [rsp + 0x50]
 xor r13d, r13d
 module_search:
 cmp r13d, r14d
 jae service_symbol_failed
 mov qword ptr [rsp + 0x18], 0
 mov edi, [rsp + r13*4 + 0xb0]
 lea rsi, [rbx + 391754]
 lea rdx, [rsp + 0x18]
 lea rax, [rbx + 33052]; call rax
 jc next_module
 cmp qword ptr [rsp + 0x18], 0
 jne service_ready
 next_module:
 inc r13d
 jmp module_search
 service_ready:

 /* Create our runtime directory; EEXIST is harmless. */
 lea rsi, [rbx + 391825]
 mov edx, 0x1ff
 mov edi, 136; xor eax, eax; lea rax, [rbx + 71538]; call rax
 /* Clear only our files, including D5's retained diagnostic archive. */
 lea rsi, [rbx + 391843]
 mov edi, 10; xor eax, eax; lea rax, [rbx + 71538]; call rax
 lea rsi, [rbx + 391870]
 mov edi, 10; xor eax, eax; lea rax, [rbx + 71538]; call rax
 lea rsi, [rbx + 391786]
 mov edi, 10; xor eax, eax; lea rax, [rbx + 71538]; call rax

 /* Decode the first bounded LZ4 block into scratch stack memory. */
 lea rdi, [rbx + 392368]
 lea rsi, [rbx + 442218]
 lea rdx, [rsp + 0x600]
 lea rcx, [rsp + 85136]
 lea rax, [rbx + 389640]; call rax
 test eax, eax
 jz decode_failed
 lea rdi, [rbx + 391843]
 lea rsi, [rsp + 0x600]
 mov edx, 83600
 lea rax, [rbx + 390152]; call rax
 test eax, eax
 jnz write_failed

 /* Reuse the same scratch region for libjbc. */
 lea rdi, [rbx + 442218]
 lea rsi, [rbx + 446678]
 lea rdx, [rsp + 0x600]
 lea rcx, [rsp + 11488]
 lea rax, [rbx + 389640]; call rax
 test eax, eax
 jz decode_failed
 lea rdi, [rbx + 391870]
 lea rsi, [rsp + 0x600]
 mov edx, 9952
 lea rax, [rbx + 390152]; call rax
 test eax, eax
 jnz write_failed

 /* Start the bundled SELF as a local child of ShellUI, not as a title. */
 /* Public 40-byte parameter buffer maps to the firmware wrapper's defaults. */
 mov rax, 0xffffffff00000028
 mov [rsp + 0x60], rax
 mov rax, 0xffffffff00000001
 mov [rsp + 0x68], rax
 mov qword ptr [rsp + 0x70], 0
 mov qword ptr [rsp + 0x78], 0
 mov qword ptr [rsp + 0x80], 0
 mov edi, [rsp + 0x28]
 lea rsi, [rbx + 391843]
 xor edx, edx
 lea rcx, [rsp + 0x60]
 call qword ptr [rsp + 0x18]
 test eax, eax
 jle launch_failed
 lea rdi, [rbx + 391903]
 jmp status

 write_failed:
 lea rdi, [rbx + 391986]
 jmp status
 decode_failed:
 lea rdi, [rbx + 392276]
 jmp status
 launch_failed:
 mov esi, eax
 lea rdi, [rbx + 392310]
 jmp status
 parent_failed:
 lea rdi, [rbx + 392335]
 jmp status
 port_busy:
 lea rdi, [rbx + 391935]
 jmp status
 socket_failed:
 mov esi, eax
 lea rdi, [rbx + 392016]
 jmp status
 lnc_image_failed:
 lea rdi, [rbx + 392041]
 jmp status
 lnc_class_failed:
 lea rdi, [rbx + 392076]
 jmp status
 appid_method_failed:
 lea rdi, [rbx + 392107]
 jmp status
 title_failed:
 lea rdi, [rbx + 392140]
 jmp status
 service_load_failed:
 mov esi, eax
 lea rdi, [rbx + 392176]
 jmp status
 service_symbol_failed:
 mov esi, eax
 lea rdi, [rbx + 392206]
 jmp status
 module_count_failed:
 lea rdi, [rbx + 392239]
 jmp status
 unavailable:
 lea rdi, [rbx + 391963]
 status:
 xor eax, eax
 lea rax, [rbx + 42682]; call rax
 mov rdx, rax
 mov rdi, r12
 lea rsi, [rbx + 391897]
 lea rax, [rbx + 148509]; call rax
 lea rdi, [rbx + 391688]
 lea rax, [rbx + 78840]; call rax
 add rsp, 0x180b8
 pop r15
 pop r14
 pop r13
 pop r12
 pop rbp
 pop rbx
 ret
 


 push rdx
 next_sequence:
 cmp rdi, rsi
 jae invalid
 movzx r8d, byte ptr [rdi]
 inc rdi
 mov r9, r8
 shr r9, 4
 cmp r9, 15
 jne literals_ready
 literals_extension:
 cmp rdi, rsi
 jae invalid
 movzx r11d, byte ptr [rdi]
 inc rdi
 add r9, r11
 jc invalid
 cmp r11, 255
 je literals_extension
 literals_ready:
 mov r11, rdi
 add r11, r9
 jc invalid
 cmp r11, rsi
 ja invalid
 mov r11, rdx
 add r11, r9
 jc invalid
 cmp r11, rcx
 ja invalid
 literal_loop:
 test r9, r9
 jz after_literals
 mov al, byte ptr [rdi]
 mov byte ptr [rdx], al
 inc rdi
 inc rdx
 dec r9
 jmp literal_loop
 after_literals:
 cmp rdi, rsi
 je finished
 mov r11, rdi
 add r11, 2
 jc invalid
 cmp r11, rsi
 ja invalid
 movzx r10d, word ptr [rdi]
 add rdi, 2
 test r10d, r10d
 jz invalid
 mov r11, rdx
 sub r11, r10
 cmp r11, qword ptr [rsp]
 jb invalid
 mov r9, r8
 and r9, 15
 add r9, 4
 mov r11, r8
 and r11, 15
 cmp r11, 15
 jne match_ready
 match_extension:
 cmp rdi, rsi
 jae invalid
 movzx r11d, byte ptr [rdi]
 inc rdi
 add r9, r11
 jc invalid
 cmp r11, 255
 je match_extension
 match_ready:
 mov r11, rdx
 add r11, r9
 jc invalid
 cmp r11, rcx
 ja invalid
 match_loop:
 test r9, r9
 jz next_sequence
 mov r11, rdx
 sub r11, r10
 mov al, byte ptr [r11]
 mov byte ptr [rdx], al
 inc rdx
 dec r9
 jmp match_loop
 finished:
 cmp rdx, rcx
 jne invalid
 mov eax, 1
 add rsp, 8
 ret
 invalid:
 xor eax, eax
 add rsp, 8
 ret



 push r13
 push r14
 push r15
 mov r14, rsi
 mov r15, rdx
 mov rsi, rdi
 mov edx, 0x601
 mov ecx, 0x1ed
 mov edi, 5; xor eax, eax; lea rax, [rbx + 71538]; call rax
 jc writer_error
 test eax, eax
 js writer_error
 mov r13, rax
 writer_loop:
 mov rsi, r13
 mov rdx, r14
 mov rcx, r15
 mov edi, 4; xor eax, eax; lea rax, [rbx + 71538]; call rax
 jc writer_close_error
 test rax, rax
 jle writer_close_error
 cmp rax, r15
 ja writer_close_error
 add r14, rax
 sub r15, rax
 jnz writer_loop
 mov rsi, r13
 mov edi, 6; xor eax, eax; lea rax, [rbx + 71538]; call rax
 jc writer_error
 xor eax, eax
 jmp writer_done
 writer_close_error:
 mov rsi, r13
 mov edi, 6; xor eax, eax; lea rax, [rbx + 71538]; call rax
 writer_error:
 mov eax, 1
 writer_done:
 pop r15
 pop r14
 pop r13
 ret
 