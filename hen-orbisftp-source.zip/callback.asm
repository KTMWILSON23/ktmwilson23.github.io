
 .byte 0xf3,0x0f,0x1e,0xfa
 push rbx
 lea rbx, [rip]
 sub rbx, 387604
 lea rax, [rbx + 40240]; call rax
 lea rdi, [rbx + 391688]
 lea rsi, [rbx + 387720]
 xor edx, edx
 xor ecx, ecx
 lea rax, [rbx + 40240]; call rax
 pop rbx
 ret
 

.byte 0xf3,0x0f,0x1e,0xfa
 push rbx
 push rbp
 push r12
 push r13
 push r14
 push r15
 sub rsp, 0xb8
 lea rbx, [rip]
 
 sub rbx, 387748
 mov r12, rsi
 mov qword ptr [rsp + 0x18], 0
 mov qword ptr [rsp + 0x20], 0
 mov qword ptr [rsp + 0x40], 0

 /* Briefly bind 1337 without listening; do not launch a competing server. */
 mov esi, 2
 mov edx, 1
 xor ecx, ecx
 mov edi, 97; xor eax, eax; lea rax, [rbx + 71538]; call rax
 jc socket_failed
 test eax, eax
 js socket_failed
 mov r13, rax
 mov qword ptr [rsp], 0x39050210
 mov qword ptr [rsp + 8], 0
 mov rsi, r13
 mov rdx, rsp
 mov ecx, 16
 mov edi, 104; xor eax, eax; lea rax, [rbx + 71538]; call rax
 setc r15b
 mov rsi, r13
 mov edi, 6; xor eax, eax; lea rax, [rbx + 71538]; call rax
 test r15b, r15b
 jnz port_busy

 /* Resolve all interfaces before creating any runtime files. */
 mov rdi, [rbx + 0x76a90]
 test rdi, rdi
 jz zip_image_failed
 lea rsi, [rbx + 391760]
 lea rdx, [rbx + 391782]
 lea rax, [rbx + 42618]; call rax
 test rax, rax
 jz zip_class_failed
 mov rdi, rax
 lea rsi, [rbx + 391790]
 mov edx, 2
 call qword ptr [rbx + 0x76548]
 test rax, rax
 jz zip_method_failed
 mov [rsp + 0x20], rax

 mov rdi, [rbx + 0x76ad0]
 test rdi, rdi
 jz lnc_image_failed
 lea rsi, [rbx + 391713]
 lea rdx, [rbx + 391733]
 lea rax, [rbx + 42618]; call rax
 test rax, rax
 jz lnc_class_failed
 mov rsi, rax
 mov rdi, [rbx + 0x76ad0]
 lea rdx, [rbx + 391741]
 mov ecx, 1
 lea rax, [rbx + 43222]; call rax
 test rax, rax
 jz appid_method_failed
 mov rbp, rax
 lea rdi, [rbx + 391750]
 xor eax, eax
 lea rax, [rbx + 42682]; call rax
 test rax, rax
 jz title_failed
 mov rdi, rax
 call rbp
 test eax, eax
 jle parent_failed
 mov [rsp + 0x28], eax

 mov dword ptr [rsp + 0x10], 0
 lea rdi, [rbx + 391809]
 lea rsi, [rsp + 0x10]
 lea rax, [rbx + 33079]; call rax
 jc service_load_failed
 test eax, eax
 js service_load_failed
 mov edi, [rsp + 0x10]
 lea rsi, [rbx + 391853]
 lea rdx, [rsp + 0x18]
 lea rax, [rbx + 33052]; call rax
 jc service_symbol_failed
 cmp qword ptr [rsp + 0x18], 0
 je service_symbol_failed

 /* Write the embedded ZIP with short-write handling. */
 lea rsi, [rbx + 391885]
 mov edx, 0x601
 mov ecx, 0x180
 mov edi, 5; xor eax, eax; lea rax, [rbx + 71538]; call rax
 jc write_failed
 test eax, eax
 js write_failed
 mov r13, rax
 lea r14, [rbx + 392528]
 mov r15d, 45594
 write_loop:
 mov rsi, r13
 mov rdx, r14
 mov rcx, r15
 mov edi, 4; xor eax, eax; lea rax, [rbx + 71538]; call rax
 jc close_write_failed
 test rax, rax
 jle close_write_failed
 cmp rax, r15
 ja close_write_failed
 add r14, rax
 sub r15, rax
 jnz write_loop
 mov rsi, r13
 mov edi, 6; xor eax, eax; lea rax, [rbx + 71538]; call rax
 jc write_failed

 /* Delete only our two known runtime files before re-extraction. */
 lea rsi, [rbx + 391932]
 mov edi, 10; xor eax, eax; lea rax, [rbx + 71538]; call rax
 lea rsi, [rbx + 391954]
 mov edi, 10; xor eax, eax; lea rax, [rbx + 71538]; call rax
 lea rdi, [rbx + 391885]
 xor eax, eax
 lea rax, [rbx + 42682]; call rax
 test rax, rax
 jz extract_failed
 mov [rsp + 0x30], rax
 lea rdi, [rbx + 391919]
 xor eax, eax
 lea rax, [rbx + 42682]; call rax
 test rax, rax
 jz extract_failed
 mov [rsp + 0x38], rax
 mov qword ptr [rsp + 0x40], 0
 mov rdi, [rsp + 0x20]
 xor esi, esi
 lea rdx, [rsp + 0x30]
 lea rcx, [rsp + 0x40]
 call qword ptr [rbx + 0x76598]
 cmp qword ptr [rsp + 0x40], 0
 jne extract_failed
 lea rsi, [rbx + 391885]
 mov edi, 10; xor eax, eax; lea rax, [rbx + 71538]; call rax

 /* Start the bundled SELF as a local child of ShellUI, not as a title. */
 mov edi, [rsp + 0x28]
 lea rsi, [rbx + 391932]
 xor edx, edx
 xor ecx, ecx
 call qword ptr [rsp + 0x18]
 test eax, eax
 jle launch_failed
 lea rdi, [rbx + 391982]
 jmp status

 close_write_failed:
 mov rsi, r13
 mov edi, 6; xor eax, eax; lea rax, [rbx + 71538]; call rax
 write_failed:
 lea rsi, [rbx + 391885]
 mov edi, 10; xor eax, eax; lea rax, [rbx + 71538]; call rax
 lea rdi, [rbx + 392079]
 jmp status
 extract_failed:
 lea rsi, [rbx + 391885]
 mov edi, 10; xor eax, eax; lea rax, [rbx + 71538]; call rax
 lea rdi, [rbx + 392439]
 jmp status
 launch_failed:
 lea rdi, [rbx + 392465]
 jmp status
 parent_failed:
 lea rdi, [rbx + 392494]
 jmp status
 port_busy:
 lea rdi, [rbx + 392014]
 jmp status
 socket_failed:
 mov esi, eax
 lea rdi, [rbx + 392111]
 jmp status
 zip_image_failed:
 lea rdi, [rbx + 392136]
 jmp status
 zip_class_failed:
 lea rdi, [rbx + 392174]
 jmp status
 zip_method_failed:
 lea rdi, [rbx + 392205]
 jmp status
 lnc_image_failed:
 lea rdi, [rbx + 392240]
 jmp status
 lnc_class_failed:
 lea rdi, [rbx + 392275]
 jmp status
 appid_method_failed:
 lea rdi, [rbx + 392306]
 jmp status
 title_failed:
 lea rdi, [rbx + 392339]
 jmp status
 service_load_failed:
 mov esi, eax
 lea rdi, [rbx + 392375]
 jmp status
 service_symbol_failed:
 mov esi, eax
 lea rdi, [rbx + 392406]
 jmp status
 unavailable:
 lea rdi, [rbx + 392042]
 status:
 xor eax, eax
 lea rax, [rbx + 42682]; call rax
 mov rdx, rax
 mov rdi, r12
 lea rsi, [rbx + 391976]
 lea rax, [rbx + 148509]; call rax
 lea rdi, [rbx + 391688]
 lea rax, [rbx + 78840]; call rax
 add rsp, 0xb8
 pop r15
 pop r14
 pop r13
 pop r12
 pop rbp
 pop rbx
 ret
 