from pathlib import Path
import hashlib
import sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'pydeps'))
sys.path.insert(0,str(ROOT))
from keystone import Ks,KS_ARCH_X86,KS_MODE_64
from unicorn import Uc,UC_ARCH_X86,UC_MODE_64
from unicorn.x86_const import *
import lz4.block
from lz4_native import SOURCE

code=bytes(Ks(KS_ARCH_X86,KS_MODE_64).asm(SOURCE,0x100000)[0])
assert len(code)<1024

def check(data,expected_success=True):
 encoded=lz4.block.compress(data,mode='high_compression',store_size=False)
 u=Uc(UC_ARCH_X86,UC_MODE_64)
 for a in [0x100000,0x200000,0x300000,0x400000]:u.mem_map(a,0x20000)
 u.mem_write(0x100000,code)
 u.mem_write(0x200000,encoded)
 u.mem_write(0x300000,b'\x5a'*len(data))
 u.mem_write(0x401000,(0x1f0000).to_bytes(8,'little'))
 u.mem_map(0x1f0000,0x1000)
 for r,v in [(UC_X86_REG_RDI,0x200000),(UC_X86_REG_RSI,0x200000+len(encoded)),
             (UC_X86_REG_RDX,0x300000),(UC_X86_REG_RCX,0x300000+len(data)),
             (UC_X86_REG_RSP,0x401000)]:u.reg_write(r,v)
 u.emu_start(0x100000,0x1f0000,count=3000000)
 assert u.reg_read(UC_X86_REG_RAX)==1
 assert bytes(u.mem_read(0x300000,len(data)))==data
 return len(encoded)

server=(ROOT/'orbisftp-binaries/eboot.bin').read_bytes()
old=b'/app0/sce_module/libjbc.sprx';new=b'/user/data/XXFHen/jbc.sprx'
server=server.replace(old,new.ljust(len(old),b'\0'))
lib=(ROOT/'orbisftp-binaries/libjbc.sprx').read_bytes()
print({'decoder_bytes':len(code),'server_block_bytes':check(server),'lib_block_bytes':check(lib),
       'server_sha256':hashlib.sha256(server).hexdigest(),'lib_sha256':hashlib.sha256(lib).hexdigest()})
