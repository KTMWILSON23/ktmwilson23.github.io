"""Static unpack/repack and display-label customization for this exact GoldHEN sample.

Python 3.10+, standard library only. Never executes the supplied payload.
Run with --help. Output files are created exclusively; existing files are not replaced.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import struct
import zlib

ORIGINAL_SHA256 = '39452f5e1c305ac9efcb4745eef7958b4db8c6d85299529f08700970b009ea4d'
CORE_SHA256 = 'd1febd41a8c28c4e9f4d8cf2c88132c5b872c1cde75e90be1389a1ee3d0d3d5b'
ENVELOPE_SHA256 = '8a832f22906b5e574c7505f257f9f5010aa05c8fab3bd95bb36edc54d5731511'
FILE_SIZE = 297496
CORE_SIZE = 638712
PREFIX_END = 0x75de
CIPHER_START = 0x75e0
SIZE_FIELD = 0x481e8
CAPACITY = SIZE_FIELD - CIPHER_START
TAG_START = 0x488a0
NONCE_START = 0x488c0
BRAND_OFFSETS = (0x38b92, 0x87e9a, 0x87f5e, 0x88170, 0x9a622)
MASK = 0xffffffff


def sha256(data):
    return hashlib.sha256(data).digest()


def rol(x, n):
    return ((x << n) & MASK) | (x >> (32 - n))


def quarter(x, a, b, c, d):
    x[a] = (x[a] + x[b]) & MASK
    x[d] = rol(x[d] ^ x[a], 16)
    x[c] = (x[c] + x[d]) & MASK
    x[b] = rol(x[b] ^ x[c], 12)
    x[a] = (x[a] + x[b]) & MASK
    x[d] = rol(x[d] ^ x[a], 8)
    x[c] = (x[c] + x[d]) & MASK
    x[b] = rol(x[b] ^ x[c], 7)


def chacha20(data, key, nonce, counter=1):
    if len(key) != 32 or len(nonce) != 12:
        raise ValueError('ChaCha20 requires a 32-byte key and 12-byte nonce')
    out = bytearray()
    for offset in range(0, len(data), 64):
        initial = list(struct.unpack('<4I', b'expand 32-byte k'))
        initial += list(struct.unpack('<8I', key))
        initial += [counter & MASK] + list(struct.unpack('<3I', nonce))
        x = initial.copy()
        for _ in range(10):
            for q in ((0,4,8,12),(1,5,9,13),(2,6,10,14),(3,7,11,15),
                      (0,5,10,15),(1,6,11,12),(2,7,8,13),(3,4,9,14)):
                quarter(x, *q)
        stream = struct.pack('<16I', *((a+b)&MASK for a,b in zip(initial,x)))
        out.extend(a ^ b for a,b in zip(data[offset:offset+64], stream))
        counter += 1
    return bytes(out)


def custom_mac(key, message):
    # This is deliberately NOT standard HMAC. The recovered code zeroes
    # bytes 32..63 of each pad instead of filling those bytes with 36/5c.
    ipad = bytes(x ^ 0x36 for x in key) + bytes(32)
    opad = bytes(x ^ 0x5c for x in key) + bytes(32)
    return sha256(opad + sha256(ipad + message))


def key_material(blob):
    digest = sha256(blob[:PREFIX_END])
    key = bytes(a^b^c^d for a,b,c,d in zip(
        blob[0x48840:0x48860], blob[0x48860:0x48880],
        blob[0x48880:0x488a0], digest))
    nonce = blob[NONCE_START:NONCE_START+12]
    # The eighth byte is a NUL; the marker is cryptographic input.
    auth_key = sha256(key + b'GoldHEN\0')
    return key, nonce, auth_key


def recover(blob):
    if len(blob) != FILE_SIZE or blob[:5] != bytes.fromhex('e9a6160000'):
        raise ValueError('Unsupported file layout; tool targets the analyzed 297496-byte sample')
    envelope = bytearray(blob)
    envelope[CIPHER_START:SIZE_FIELD+4] = bytes(SIZE_FIELD+4-CIPHER_START)
    envelope[TAG_START:TAG_START+32] = bytes(32)
    if sha256(envelope).hex() != ENVELOPE_SHA256:
        raise ValueError('Outer loader differs from the analyzed build')
    length = struct.unpack_from('<I', blob, SIZE_FIELD)[0]
    if not 6 <= length <= CAPACITY:
        raise ValueError('Encrypted length is outside the reserved region')
    ciphertext = blob[CIPHER_START:CIPHER_START+length]
    key, nonce, auth_key = key_material(blob)
    tag = custom_mac(auth_key, nonce + ciphertext)
    if tag != blob[TAG_START:TAG_START+32]:
        raise ValueError('Authentication failed: file changed or this is a different build')
    compressed = chacha20(ciphertext, key, nonce)
    decoder = zlib.decompressobj()
    core = decoder.decompress(compressed, CORE_SIZE + 1)
    if (not decoder.eof or decoder.unconsumed_tail or decoder.unused_data
            or len(core) != CORE_SIZE):
        raise ValueError('Unexpected zlib stream or core size')
    if len(core) > 3*length:
        raise ValueError('Core exceeds the loader allocation (3 * compressed length)')
    meta = {'payload_size':len(blob), 'payload_sha256':sha256(blob).hex(),
            'original_sample':sha256(blob).hex()==ORIGINAL_SHA256,
            'ciphertext_offset':hex(CIPHER_START), 'ciphertext_size':length,
            'authentication_verified':True, 'core_size':len(core),
            'core_sha256':sha256(core).hex(),
            'core_matches_original':sha256(core).hex()==CORE_SHA256}
    return core, compressed, meta


def require_original(blob):
    if sha256(blob).hex() != ORIGINAL_SHA256:
        raise ValueError('Use the original analyzed goldhen.bin as the repacking template')


def rebuild(template, core):
    require_original(template)
    if len(core) != CORE_SIZE:
        raise ValueError('Core size must remain 638712 bytes; relocation is not implemented')
    # Level 7 reproduces the original compressed bytes exactly on zlib 1.3.2.
    # Level 9 is a fallback when an edit would otherwise exceed the fixed slot.
    # This verifies static format constraints, not all runtime memory needs.
    compressed = zlib.compress(core, 7)
    if len(compressed) > CAPACITY:
        compressed = zlib.compress(core, 9)
    if len(compressed) > CAPACITY or 3*len(compressed) < len(core):
        raise ValueError('Compressed core does not fit the loader size/allocation constraints')
    key, nonce, auth_key = key_material(template)
    ciphertext = chacha20(compressed, key, nonce)
    out = bytearray(template)
    out[CIPHER_START:CIPHER_START+len(ciphertext)] = ciphertext
    # Preserve all fixed offsets. Bytes after the new ciphertext are ignored.
    struct.pack_into('<I', out, SIZE_FIELD, len(ciphertext))
    out[TAG_START:TAG_START+32] = custom_mac(auth_key, nonce + ciphertext)
    result = bytes(out)
    recovered, _, meta = recover(result)
    if recovered != core:
        raise ValueError('Repacking verification failed')
    return result, meta


def brand_core(core, name):
    if sha256(core).hex() != CORE_SHA256:
        raise ValueError('Display branding requires the original recovered core')
    if re.fullmatch(r'[A-Za-z0-9_-]{1,7}', name) is None:
        raise ValueError('Choose 1-7 ASCII letters, digits, underscores, or hyphens')
    out = bytearray(core)
    label = name.encode('ascii').ljust(7, b' ')
    for offset in BRAND_OFFSETS:
        if out[offset:offset+7] != b'GoldHEN':
            raise ValueError(f'Unexpected display text at core offset {offset:#x}')
        out[offset:offset+7] = label
    return bytes(out)


def write_new(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as f:
        f.write(data)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    info = sub.add_parser('info', help='Verify and identify a supported payload')
    info.add_argument('payload')
    unpack = sub.add_parser('unpack', help='Statically decrypt and decompress')
    unpack.add_argument('payload')
    unpack.add_argument('directory', help='New output directory')
    repack = sub.add_parser('repack', help='Repack a same-size edited core using the original template')
    repack.add_argument('original')
    repack.add_argument('core')
    repack.add_argument('output')
    brand = sub.add_parser('brand', help='Change five display labels; retain SiSTRo credit and integration names')
    brand.add_argument('original')
    brand.add_argument('--name', required=True)
    brand.add_argument('--output', required=True)
    args = parser.parse_args()
    if args.command in ('info', 'unpack'):
        core, compressed, meta = recover(Path(args.payload).read_bytes())
        if args.command == 'unpack':
            dest = Path(args.directory)
            dest.mkdir(parents=True, exist_ok=False)
            write_new(dest/'unpacked_core.bin', core)
            write_new(dest/'decrypted_compressed.zlib', compressed)
            write_new(dest/'metadata.json', (json.dumps(meta, indent=2)+'\n').encode())
        print(json.dumps(meta, indent=2))
    else:
        template = Path(args.original).read_bytes()
        require_original(template)
        if args.command == 'brand':
            original_core, _, _ = recover(template)
            core = brand_core(original_core, args.name)
        else:
            core = Path(args.core).read_bytes()
        result, meta = rebuild(template, core)
        write_new(args.output, result)
        meta['console_tested'] = False
        if args.command == 'brand':
            meta['display_name'] = args.name
            meta['modified_core_offsets'] = [hex(x) for x in BRAND_OFFSETS]
        print(json.dumps(meta, indent=2))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, zlib.error) as error:
        raise SystemExit(f'Error: {error}')
