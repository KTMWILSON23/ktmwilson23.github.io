OrbisFTP by OSM-Made: https://github.com/OSM-Made/OrbisFTP
Snapshot: 35b14a4819994882251ac008f0581e2c7490ac1b
The included original server binary and libjbc match that repository. The builder patches only its libjbc path, so it can run outside an installed app. The installer and PKG are excluded. Existing GoldHEN credits are preserved.
