"""Experimental bundled OrbisFTP backend: no title installation or installer."""
from pathlib import Path
import sys,struct,json,hashlib,zlib,io,re,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'pydeps'));sys.path.insert(0,str(ROOT))
import lz4.block
from lz4_native import SOURCE as LZ4_SOURCE
from keystone import Ks,KS_ARCH_X86,KS_MODE_64
import expanded_hen_envelope as envelope
from PIL import Image
OUT=ROOT/'build'
ELF=0x13868;DDS_A=0x6cc80;DDS_B=0x82270;HOOK=0x9da0
ID='id_xxfhen_orbis_d7'
ks=Ks(KS_ARCH_X86,KS_MODE_64)
def asm(src,addr):return bytes(ks.asm(src,addr)[0])
def call(addr):return f'lea rax, [rbx + {addr}]; call rax'
def sc(n):return f'mov edi, {n}; xor eax, eax; {call(0x11772)}'

def build():
 base=(ROOT/'baseline/XXFHen.bin').read_bytes()
 assert hashlib.sha256(base).hexdigest()=='2defcf90b3a64b629c2d5914009cf18d1009544a1cf8b1a9a1ea946eb92d3396'
 core,_,_=envelope.original.recover(base);edit=bytearray(core)
 logo_base,_,_=envelope.original.recover((ROOT/'baseline/logo-build3.bin').read_bytes())
 edit[0x69ad7:0x6cc7c]=logo_base[0x69ad7:0x6cc7c] # Remove superseded app-launch code from private PNG chunk.
 server=(ROOT/'orbisftp-binaries/eboot.bin').read_bytes()
 lib=(ROOT/'orbisftp-binaries/libjbc.sprx').read_bytes()
 old=b'/app0/sce_module/libjbc.sprx';new=b'/user/data/XXFHen/jbc.sprx'
 assert server.count(old+b'\0')==1 and len(new)<=len(old)
 patch_at=server.index(old+b'\0');patched=server.replace(old,new.ljust(len(old),b'\0'))
 compressed_server=lz4.block.compress(patched,mode='high_compression',store_size=False)
 compressed_lib=lz4.block.compress(lib,mode='high_compression',store_size=False)
 assert lz4.block.decompress(compressed_server,uncompressed_size=len(patched))==patched
 assert lz4.block.decompress(compressed_lib,uncompressed_size=len(lib))==lib
 bundle=compressed_server+compressed_lib
 # Use the already-encoded 128x128 mip and following seven levels. Store the
 # bundle/code in the freed physical slot, outside the new DDS logical length.
 old_dds=core[DDS_A:DDS_B];header=bytearray(old_dds[:128])
 assert struct.unpack_from('<III',header,12)==(256,256,65536)
 struct.pack_into('<III',header,12,128,128,16384);struct.pack_into('<I',header,28,8)
 dds=bytes(header)+old_dds[128+65536:]
 with Image.open(io.BytesIO(dds)) as image:image.load();assert image.size==(128,128)
 code_core=(DDS_A+len(dds)+15)&~15;code=code_core-ELF;callback=code+128
 strings={
  'id':ID,'lnc_ns':'Sce.Vsh.ShellUI.Lnc','lnc_class':'LncUtil','getappid':'GetAppId','shellui':'NPXS20001',
  'spawn_symbol':'sceSystemServiceAddLocalProcess',
  'old_zip_path':'/user/data/xxfhen-orbisftp-runtime.zip','runtime_dir':'/user/data/XXFHen','runtime_bin':'/user/data/XXFHen/oftp.bin','runtime_lib':'/user/data/XXFHen/jbc.sprx',
  'value':'Value','requested':'Bundled server launch requested','busy':'Port 1337 is already in use',
  'unsupported':'D7 unexpected dispatch','write_failed':'OF14 native file write failed',
  'socket_failed':'OF01 socket error 0x%08x',
  'lnc_image_failed':'OF05 platform assembly unavailable',
  'lnc_class_failed':'OF06 LncUtil class unavailable',
  'appid_method_failed':'OF07 GetAppId method unavailable',
  'title_failed':'OF08 title string allocation failed',
  'service_load_failed':'OF09 module list error 0x%08x',
  'service_symbol_failed':'OF10 process export error 0x%08x',
  'module_count_failed':'OF11 module list exceeds 256 entries',

  'decode_failed':'OF13 embedded block decode failed','launch_failed':'OF12 launch error 0x%08x','parent_failed':'ShellUI app ID unavailable',
 }
 offsets={};string_data=bytearray();reserve=4096
 for k,v in strings.items():offsets[k]=code+reserve+len(string_data);string_data.extend(v.encode()+b'\0')
 bundle_offset=(code+reserve+len(string_data)+15)&~15
 decoder_offset=code+2048
 writer_offset=code+2560
 assert ELF+bundle_offset+len(bundle)<=DDS_B
 def lea(reg,key):return f'lea {reg}, [rbx + {offsets[key]}]'
 wrapper=f'''
 .byte 0xf3,0x0f,0x1e,0xfa
 push rbx
 lea rbx, [rip]
 sub rbx, {code+12}
 {call(0x9d30)}
 {lea('rdi','id')}
 lea rsi, [rbx + {callback}]
 xor edx, edx
 xor ecx, ecx
 {call(0x9d30)}
 pop rbx
 ret
 '''
 wrapper_bytes=asm(wrapper,code);assert len(wrapper_bytes)<=128
 prelude='''.byte 0xf3,0x0f,0x1e,0xfa
 push rbx
 push rbp
 push r12
 push r13
 push r14
 push r15
 sub rsp, 0x180b8
 lea rbx, [rip]
 '''
 prelude_len=len(asm(prelude,callback))
 body=prelude+f'''
 sub rbx, {callback+prelude_len}
 mov r12, rsi
 mov qword ptr [rsp + 0x18], 0
 mov qword ptr [rsp + 0x20], 0
 mov qword ptr [rsp + 0x40], 0

 /* Briefly bind 1337 without listening; do not launch a competing server. */
 mov esi, 2
 mov edx, 1
 xor ecx, ecx
 {sc(97)}
 jc socket_failed
 test eax, eax
 js socket_failed
 mov r13, rax
 mov qword ptr [rsp], 0x39050210
 mov qword ptr [rsp + 8], 0
 mov rsi, r13
 mov rdx, rsp
 mov ecx, 16
 {sc(104)}
 setc r15b
 mov rsi, r13
 {sc(6)}
 test r15b, r15b
 jnz port_busy

 mov rdi, [rbx + 0x76ad0]
 test rdi, rdi
 jz lnc_image_failed
 {lea('rsi','lnc_ns')}
 {lea('rdx','lnc_class')}
 {call(0xa67a)}
 test rax, rax
 jz lnc_class_failed
 mov rsi, rax
 mov rdi, [rbx + 0x76ad0]
 {lea('rdx','getappid')}
 mov ecx, 1
 {call(0xa8d7)}
 test rax, rax
 jz appid_method_failed
 mov rbp, rax
 {lea('rdi','shellui')}
 xor eax, eax
 {call(0xa6ba)}
 test rax, rax
 jz title_failed
 mov rdi, rax
 call rbp
 test eax, eax
 jle parent_failed
 mov [rsp + 0x28], eax

 /* Find the export in existing modules; do not load a library by path. */
 mov qword ptr [rsp + 0x50], 0
 lea rsi, [rsp + 0xb0]
 mov edx, 256
 lea rcx, [rsp + 0x50]
 {sc(592)}
 jc service_load_failed
 test eax, eax
 js service_load_failed
 cmp qword ptr [rsp + 0x50], 256
 ja module_count_failed
 mov r14d, [rsp + 0x50]
 xor r13d, r13d
 module_search:
 cmp r13d, r14d
 jae service_symbol_failed
 mov qword ptr [rsp + 0x18], 0
 mov edi, [rsp + r13*4 + 0xb0]
 {lea('rsi','spawn_symbol')}
 lea rdx, [rsp + 0x18]
 {call(0x811c)}
 jc next_module
 cmp qword ptr [rsp + 0x18], 0
 jne service_ready
 next_module:
 inc r13d
 jmp module_search
 service_ready:

 /* Create our runtime directory; EEXIST is harmless. */
 {lea('rsi','runtime_dir')}
 mov edx, 0x1ff
 {sc(136)}
 /* Clear only our files, including D5's retained diagnostic archive. */
 {lea('rsi','runtime_bin')}
 {sc(10)}
 {lea('rsi','runtime_lib')}
 {sc(10)}
 {lea('rsi','old_zip_path')}
 {sc(10)}

 /* Decode the first bounded LZ4 block into scratch stack memory. */
 lea rdi, [rbx + {bundle_offset}]
 lea rsi, [rbx + {bundle_offset+len(compressed_server)}]
 lea rdx, [rsp + 0x600]
 lea rcx, [rsp + {0x600+len(patched)}]
 lea rax, [rbx + {decoder_offset}]; call rax
 test eax, eax
 jz decode_failed
 {lea('rdi','runtime_bin')}
 lea rsi, [rsp + 0x600]
 mov edx, {len(patched)}
 lea rax, [rbx + {writer_offset}]; call rax
 test eax, eax
 jnz write_failed

 /* Reuse the same scratch region for libjbc. */
 lea rdi, [rbx + {bundle_offset+len(compressed_server)}]
 lea rsi, [rbx + {bundle_offset+len(bundle)}]
 lea rdx, [rsp + 0x600]
 lea rcx, [rsp + {0x600+len(lib)}]
 lea rax, [rbx + {decoder_offset}]; call rax
 test eax, eax
 jz decode_failed
 {lea('rdi','runtime_lib')}
 lea rsi, [rsp + 0x600]
 mov edx, {len(lib)}
 lea rax, [rbx + {writer_offset}]; call rax
 test eax, eax
 jnz write_failed

 /* Start the bundled SELF as a local child of ShellUI, not as a title. */
 /* Public 40-byte parameter buffer maps to the firmware wrapper's defaults. */
 mov rax, 0xffffffff00000028
 mov [rsp + 0x60], rax
 mov rax, 0xffffffff00000001
 mov [rsp + 0x68], rax
 mov qword ptr [rsp + 0x70], 0
 mov qword ptr [rsp + 0x78], 0
 mov qword ptr [rsp + 0x80], 0
 mov edi, [rsp + 0x28]
 {lea('rsi','runtime_bin')}
 xor edx, edx
 lea rcx, [rsp + 0x60]
 call qword ptr [rsp + 0x18]
 test eax, eax
 jle launch_failed
 {lea('rdi','requested')}
 jmp status

 write_failed:
 {lea('rdi','write_failed')}
 jmp status
 decode_failed:
 {lea('rdi','decode_failed')}
 jmp status
 launch_failed:
 mov esi, eax
 {lea('rdi','launch_failed')}
 jmp status
 parent_failed:
 {lea('rdi','parent_failed')}
 jmp status
 port_busy:
 {lea('rdi','busy')}
 jmp status
 socket_failed:
 mov esi, eax
 {lea('rdi','socket_failed')}
 jmp status
 lnc_image_failed:
 {lea('rdi','lnc_image_failed')}
 jmp status
 lnc_class_failed:
 {lea('rdi','lnc_class_failed')}
 jmp status
 appid_method_failed:
 {lea('rdi','appid_method_failed')}
 jmp status
 title_failed:
 {lea('rdi','title_failed')}
 jmp status
 service_load_failed:
 mov esi, eax
 {lea('rdi','service_load_failed')}
 jmp status
 service_symbol_failed:
 mov esi, eax
 {lea('rdi','service_symbol_failed')}
 jmp status
 module_count_failed:
 {lea('rdi','module_count_failed')}
 jmp status
 unavailable:
 {lea('rdi','unsupported')}
 status:
 xor eax, eax
 {call(0xa6ba)}
 mov rdx, rax
 mov rdi, r12
 {lea('rsi','value')}
 {call(0x2441d)}
 {lea('rdi','id')}
 {call(0x133f8)}
 add rsp, 0x180b8
 pop r15
 pop r14
 pop r13
 pop r12
 pop rbp
 pop rbx
 ret
 '''
 body_bytes=asm(body,callback);assert len(body_bytes)+128<=2048
 decoder_bytes=asm(LZ4_SOURCE,decoder_offset)
 writer=f"""
 push r13
 push r14
 push r15
 mov r14, rsi
 mov r15, rdx
 mov rsi, rdi
 mov edx, 0x601
 mov ecx, 0x1ed
 {sc(5)}
 jc writer_error
 test eax, eax
 js writer_error
 mov r13, rax
 writer_loop:
 mov rsi, r13
 mov rdx, r14
 mov rcx, r15
 {sc(4)}
 jc writer_close_error
 test rax, rax
 jle writer_close_error
 cmp rax, r15
 ja writer_close_error
 add r14, rax
 sub r15, rax
 jnz writer_loop
 mov rsi, r13
 {sc(6)}
 jc writer_error
 xor eax, eax
 jmp writer_done
 writer_close_error:
 mov rsi, r13
 {sc(6)}
 writer_error:
 mov eax, 1
 writer_done:
 pop r15
 pop r14
 pop r13
 ret
 """
 writer_bytes=asm(writer,writer_offset)
 assert decoder_offset+len(decoder_bytes)<=writer_offset
 assert writer_offset+len(writer_bytes)<=code+reserve
 slot=bytearray(DDS_B-DDS_A);slot[:len(dds)]=dds
 off=code_core-DDS_A;slot[off:off+len(wrapper_bytes)]=wrapper_bytes
 slot[off+128:off+128+len(body_bytes)]=body_bytes
 slot[ELF+decoder_offset-DDS_A:ELF+decoder_offset-DDS_A+len(decoder_bytes)]=decoder_bytes
 slot[ELF+writer_offset-DDS_A:ELF+writer_offset-DDS_A+len(writer_bytes)]=writer_bytes
 slot[off+reserve:off+reserve+len(string_data)]=string_data
 off=ELF+bundle_offset-DDS_A;slot[off:off+len(bundle)]=bundle
 edit[DDS_A:DDS_B]=slot;struct.pack_into('<I',edit,DDS_B,len(dds))
 edit[ELF+HOOK:ELF+HOOK+5]=asm(f'call {code}',HOOK)
 a,b=0x38af8,0x455fa;xml=core[a:b];before=ET.fromstring(xml)
 pattern=rb'(<button id="id_xxfhen_start_orbisftp"[^>]* second_title=")[^"]*(")'
 xml,n=re.subn(pattern,rb'\g<1>Start bundled OrbisFTP. No separate app installation required.\2',xml);assert n==1
 xml=xml.replace(b'id_xxfhen_start_orbisftp',ID.encode()).replace(b'title="Start OrbisFTP"',b'title="Start OrbisFTP [D7]"')
 xml=xml.rstrip();assert len(xml)<=b-a;xml=xml.ljust(b-a,b' ')
 after=ET.fromstring(xml)
 assert [ID if n.attrib.get('id')=='id_xxfhen_start_orbisftp' else n.attrib.get('id') for n in before.iter()]==[n.attrib.get('id') for n in after.iter()]
 edit[a:b]=xml
 startup_length=edit[0x9a622:0x9a622+40].index(b'\n')+1
 assert edit[0x9a622+startup_length:0x9a622+startup_length+32].startswith(b'Coded by SiSTRo\0')
 edit[0x9a622:0x9a622+startup_length]=b'XXFHen D7 ready!'.ljust(startup_length-1,b' ')+b'\n'
 payload,report=envelope.build(bytes(edit))
 report.update(personal_revision='orbisftp-bundled-diagnostic-D7',console_tested=False,installer_included=False,installed_title_dependency=False,
  original_server_sha256=hashlib.sha256(server).hexdigest(),bundled_server_sha256=hashlib.sha256(patched).hexdigest(),libjbc_sha256=hashlib.sha256(lib).hexdigest(),
  server_path_patch_offset=hex(patch_at),bundle_lz4_bytes=len(bundle),bundle_lz4_sha256=hashlib.sha256(bundle).hexdigest(),compressed_server_bytes=len(compressed_server),compressed_lib_bytes=len(compressed_lib),
  callback_bytes=len(body_bytes),callback_elf_offset=hex(callback),code_elf_offset=hex(code),bundle_elf_offset=hex(bundle_offset),
  dds_dimensions=[128,128],dds_mipmaps=8,dds_logical_length=len(dds),core_size=len(edit),
  runtime_files=['/user/data/XXFHen/oftp.bin','/user/data/XXFHen/jbc.sprx'],temporary_archive=None,
  launches_via='sceSystemServiceAddLocalProcess with ShellUI parent app ID',original_server_startup_behavior_preserved=True)
 return payload,bytes(edit),report,{'code':code,'callback':callback,'decoder_offset':decoder_offset,'writer_offset':writer_offset,'offsets':offsets,'bundle_offset':bundle_offset,'bundle':bundle,'assembly':wrapper+'\n\n'+body+'\n\n'+LZ4_SOURCE+'\n\n'+writer,'dds':dds}

if __name__=='__main__':
 payload,core,report,info=build();OUT.mkdir(exist_ok=True)
 (OUT/'xxfhen.bin').write_bytes(payload);(OUT/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
 (OUT/'callback.asm').write_text(info['assembly']);(ROOT/'build/embedded-core.bin').write_bytes(core)
 (ROOT/'build/patch-info.json').write_text(json.dumps({k:v for k,v in info.items() if isinstance(v,(dict,int))},indent=2)+'\n')
 with Image.open(io.BytesIO(info['dds'])) as image:image.save(OUT/'top-menu-preview.png')
 print(json.dumps({k:v for k,v in report.items() if k!='relocated_rip_references'},indent=2))
