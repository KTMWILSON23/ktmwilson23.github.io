"""Emulate original menu dispatch plus bundled backend with virtual PS4 APIs/files."""
from pathlib import Path
import sys,json,struct,hashlib,io,zipfile
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'pydeps'));sys.path.insert(0,str(ROOT))
import build_embedded_orbis as build
from unicorn import Uc,UC_ARCH_X86,UC_MODE_64,UC_HOOK_CODE
from unicorn.x86_const import *
payload,core,receipt,info=build.build()
elf=core[build.ELF:0x8b290]

def run(base,case):
 u=Uc(UC_ARCH_X86,UC_MODE_64);u.mem_map(base,0x100000);u.mem_write(base,elf)
 stack=0x2000000;heap=0x3000000;ext=0x4000000
 for addr in [stack,heap,ext]:u.mem_map(addr,0x40000)
 stop=ext+0x3ff00;alloc=heap+0x1000;records={};handlers={};files={};fdpaths={};state={'spawn_calls':0,'statuses':[],'original_press':0,'zip_write_calls':0,'extracted':False,'syscalls':[]}
 def reg(r):return u.reg_read(r)
 def q(a):return int.from_bytes(u.mem_read(a,8),'little')
 def w(a,v):u.mem_write(a,(v&0xffffffffffffffff).to_bytes(8,'little'))
 def text(a):
  b=bytearray()
  while a and len(b)<256:
   c=u.mem_read(a+len(b),1)
   if c==b'\0':break
   b.extend(c)
  return b.decode()
 def ret(v=0,carry=False):
  u.reg_write(UC_X86_REG_RAX,v&0xffffffffffffffff)
  flags=reg(UC_X86_REG_EFLAGS);u.reg_write(UC_X86_REG_EFLAGS,(flags|1) if carry else (flags&~1))
 def mock(offset,fn,absolute=False):
  a=offset if absolute else base+offset;u.mem_write(a,b'\xc3');handlers[a]=fn
 def malloc():
  nonlocal alloc
  a=alloc;alloc+=0x80;ret(a)
 mock(0x819d,malloc)
 def insert():records[text(reg(UC_X86_REG_RSI))]=reg(UC_X86_REG_RDX);ret()
 mock(0x7e37,insert)
 def klass():
  ns=text(reg(UC_X86_REG_RSI));name=text(reg(UC_X86_REG_RDX))
  assert (ns,name) in [('System.IO.Compression','ZipFile'),('Sce.Vsh.ShellUI.Lnc','LncUtil')]
  fail=(case=='missing_zip_class' and name=='ZipFile') or (case=='missing_lnc_class' and name=='LncUtil')
  ret(0 if fail else heap+(0x800 if name=='ZipFile' else 0x900))
 mock(0xa67a,klass)
 method=heap+0xa00
 def extract_method():
  assert reg(UC_X86_REG_RDI)==heap+0x800 and text(reg(UC_X86_REG_RSI))=='ExtractToDirectory' and reg(UC_X86_REG_RDX)==2
  ret(0 if case=='missing_extract_method' else method)
 method_stub=ext+0x100
 mock(method_stub,extract_method,True);w(base+0x76548,method_stub)
 appid_stub=ext+0x200
 def get_method():
  assert reg(UC_X86_REG_RSI)==heap+0x900 and text(reg(UC_X86_REG_RDX))=='GetAppId' and reg(UC_X86_REG_RCX)==1
  ret(0 if case=='missing_getappid' else appid_stub)
 mock(0xa8d6,get_method)
 def appid():assert text(reg(UC_X86_REG_RDI))=='NPXS20001';ret(0 if case=='missing_parent' else 0x10000001)
 mock(appid_stub,appid,True)
 def newstr():
  a=reg(UC_X86_REG_RDI);s=text(a)
  fail=(case=='source_string_failed' and s=='/data/xxfhen-orbisftp-runtime.zip') or (case=='dest_string_failed' and s=='/data/XXFHen')
  ret(0 if fail else a)
 mock(0xa6ba,newstr)
 w(base+0x76a90,0 if case=='missing_zip_image' else heap+0xb00)
 w(base+0x76ad0,0 if case=='missing_lnc_image' else heap+0xc00)
 def loadmodule():
  assert text(reg(UC_X86_REG_RDI))=='/system/common/lib/libSceSystemService.sprx'
  u.mem_write(reg(UC_X86_REG_RSI),(16).to_bytes(4,'little'));ret(2 if case=='module_load_failed' else 0,case=='module_load_failed')
 mock(0x8137,loadmodule)
 spawn_stub=ext+0x300
 def dlsym():
  assert reg(UC_X86_REG_RDI)==16 and text(reg(UC_X86_REG_RSI))=='sceSystemServiceAddLocalProcess'
  w(reg(UC_X86_REG_RDX),0 if case=='missing_spawn_symbol' else spawn_stub);ret()
 mock(0x811c,dlsym)
 def syscall():
  number=reg(UC_X86_REG_RDI);a,b,c=[reg(r) for r in [UC_X86_REG_RSI,UC_X86_REG_RDX,UC_X86_REG_RCX]]
  state['syscalls'].append(number)
  if number==97:
   assert (a,b,c)==(2,1,0);ret(13 if case=='socket_error' else 5,case=='socket_error')
  elif number==104:
   assert a==5 and c==16 and bytes(u.mem_read(b,16))==struct.pack('<QQ',0x39050210,0)
   ret(48 if case=='port_busy' else 0,case=='port_busy')
  elif number==6:
   assert a in [5,7];ret(5 if case=='close_failed' and a==7 else 0,case=='close_failed' and a==7)
   fdpaths.pop(a,None)
  elif number==5:
   p=text(a);assert p=='/data/xxfhen-orbisftp-runtime.zip' and b==0x601 and c==0x180
   if case=='open_failed':ret(13,True)
   else:files[p]=b'';fdpaths[7]=p;ret(7)
  elif number==4:
   assert a==7 and a in fdpaths;state['zip_write_calls']+=1
   if case=='write_failed' and state['zip_write_calls']>1:ret(5,True);return
   if case=='write_zero':ret(0);return
   if case=='write_overshoot':ret(c+1);return
   n=min(c,4096) if case in ['short_writes','write_failed'] else c
   files[fdpaths[a]]+=bytes(u.mem_read(b,n));ret(n)
  elif number==10:
   p=text(a);assert p in ['/data/XXFHen/oftp.bin','/data/XXFHen/jbc.sprx','/data/xxfhen-orbisftp-runtime.zip']
   files.pop(p,None);ret()
  else:raise AssertionError(('Unexpected syscall',number))
 mock(0x11772,syscall)
 def invoke():
  assert reg(UC_X86_REG_RDI)==method and reg(UC_X86_REG_RSI)==0
  arg=reg(UC_X86_REG_RDX);source=text(q(arg));dest=text(q(arg+8));exc=reg(UC_X86_REG_RCX)
  assert source=='/data/xxfhen-orbisftp-runtime.zip' and dest=='/data/XXFHen'
  assert files[source]==info['bundle']
  if case=='extract_exception':w(exc,heap+0xd00);ret();return
  with zipfile.ZipFile(io.BytesIO(files[source])) as z:
   assert set(z.namelist())=={'oftp.bin','jbc.sprx'}
   for name in z.namelist():files[dest+'/'+name]=z.read(name)
  w(exc,0);state['extracted']=True;ret()
 invoke_stub=ext+0x400;mock(invoke_stub,invoke,True);w(base+0x76598,invoke_stub)
 def spawn():
  assert reg(UC_X86_REG_RDI)==0x10000001 and text(reg(UC_X86_REG_RSI))=='/data/XXFHen/oftp.bin'
  assert reg(UC_X86_REG_RDX)==0 and reg(UC_X86_REG_RCX)==0
  assert hashlib.sha256(files['/data/XXFHen/oftp.bin']).hexdigest()==receipt['bundled_server_sha256']
  assert hashlib.sha256(files['/data/XXFHen/jbc.sprx']).hexdigest()==receipt['libjbc_sha256']
  assert b'/app0/sce_module/libjbc.sprx' not in files['/data/XXFHen/oftp.bin']
  state['spawn_calls']+=1;ret(0x80940001 if case=='spawn_failed' else 0 if case=='spawn_zero' else 0x60000001)
 mock(spawn_stub,spawn,True)
 element=heap+0x500;instance=heap+0x600;event=heap+0x700
 def status():
  assert reg(UC_X86_REG_RDI)==element and text(reg(UC_X86_REG_RSI))=='Value'
  state['statuses'].append(text(reg(UC_X86_REG_RDX)));ret()
 mock(0x2441d,status)
 def reset():assert text(reg(UC_X86_REG_RDI))==build.ID;ret()
 mock(0x133f8,reset)
 canaries={r:0xc0000000+i for i,r in enumerate([UC_X86_REG_RBX,UC_X86_REG_RBP,UC_X86_REG_R12,UC_X86_REG_R13,UC_X86_REG_R14,UC_X86_REG_R15])}
 def execute(addr,args):
  for r,v in canaries.items():u.reg_write(r,v)
  sp=stack+0x3ff08;w(sp,stop);u.reg_write(UC_X86_REG_RSP,sp)
  for r,v in zip([UC_X86_REG_RDI,UC_X86_REG_RSI,UC_X86_REG_RDX],args):u.reg_write(r,v)
  u.emu_start(addr,stop,count=100000)
  assert reg(UC_X86_REG_RIP)==stop and reg(UC_X86_REG_RSP)==sp+8
  assert all(reg(r)==v for r,v in canaries.items())
 def oncode(uc,addr,size,user):
  if addr in handlers:
   assert (reg(UC_X86_REG_RSP)+8)%16==0,hex(addr)
   handlers[addr]()
 u.hook_add(UC_HOOK_CODE,oncode)
 id_old=heap+0x100;u.mem_write(id_old,b'existing_entry\0')
 execute(base+info['code'],[id_old,ext+0x800,0])
 assert set(records)=={'existing_entry',build.ID} and q(records[build.ID]+0x28)==base+info['callback']
 mock(ext+0x800,lambda:ret(),True)
 id_ptr=id_old if case=='unrelated_entry' else base+info['offsets']['id'];value=heap+0x200;u.mem_write(value,b'Ready\0')
 def prop():
  assert reg(UC_X86_REG_RDI)==element
  name=text(reg(UC_X86_REG_RSI));assert name in ['Id','Value'];ret(id_ptr if name=='Id' else value)
 mock(0x241ad,prop)
 utf=ext+0x500;mock(utf,lambda:ret(reg(UC_X86_REG_RDI)),True);w(base+0x76510,utf)
 free=ext+0x600;mock(free,lambda:ret(),True);w(base+0x764e0,free)
 def lookup():
  ptr=records.get(text(reg(UC_X86_REG_RSI)));w(reg(UC_X86_REG_RDX),ptr or 0);ret(0 if ptr else 1)
 mock(0x7f50,lookup)
 def original():
  assert (reg(UC_X86_REG_RSI),reg(UC_X86_REG_RDX),reg(UC_X86_REG_RCX))==(instance,element,event)
  state['original_press']+=1;ret()
 mock(0xf02c,original);detour=heap+0xe00;w(base+0x76c90,detour);w(detour+8,ext+0x900)
 execute(base+0x102bc,[instance,element,event])
 expected='Bundled server launch requested' if case in ['success','short_writes'] else 'Port 1337 is already in use' if case=='port_busy' else 'ShellUI app ID unavailable' if case=='missing_parent' else 'Runtime file preparation failed' if case in ['open_failed','write_failed','write_zero','write_overshoot','close_failed'] else 'Runtime extraction failed' if case in ['source_string_failed','dest_string_failed','extract_exception'] else 'Bundled server launch failed' if case in ['spawn_failed','spawn_zero'] else 'Bundled server interface unavailable'
 assert state['statuses']==([] if case=='unrelated_entry' else [expected]),(case,state)
 assert state['spawn_calls']==(1 if case in ['success','short_writes','spawn_failed','spawn_zero'] else 0)
 assert state['original_press']==1
 assert '/data/xxfhen-orbisftp-runtime.zip' not in files
 if case in ['success','short_writes','spawn_failed','spawn_zero']:assert set(files)=={'/data/XXFHen/oftp.bin','/data/XXFHen/jbc.sprx'}
 return {'base':hex(base),'case':case,**state,'stack_and_registers_preserved':True,'installed_app_launch_called':False,'real_console_access':False}

cases=['success','short_writes','port_busy','socket_error','missing_zip_image','missing_zip_class','missing_extract_method','missing_lnc_image','missing_lnc_class','missing_getappid','missing_parent','module_load_failed','missing_spawn_symbol','open_failed','write_failed','write_zero','write_overshoot','close_failed','source_string_failed','dest_string_failed','extract_exception','spawn_failed','spawn_zero','unrelated_entry']
results=[run(base,case) for base in [0x10000000,0x910000000] for case in cases]
report={'passed':len(results),'payload_sha256':receipt['payload_sha256'],'tests':results,'limitation':'PS4 APIs and filesystem are modeled. Does not prove live process creation, libjbc loading, FTP startup or firmware compatibility.'}
(build.OUT/'backend-emulator-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'passed':len(results),'installed_app_dependency':False,'console_executed':False}))
