"""Run actual outer hash/auth/decrypt/inflate code in an isolated x86 emulator.

Kernel allocator and memcpy are mocked; stop before the decoded HEN entry runs.
"""
from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'pydeps'));sys.path.insert(0,str(ROOT))
import expanded_hen_envelope as e
from unicorn import Uc,UC_ARCH_X86,UC_MODE_64,UC_HOOK_CODE
from unicorn.x86_const import *

def test(blob,expected,base):
 u=Uc(UC_ARCH_X86,UC_MODE_64)
 u.mem_map(base,((len(blob)+0x10000+4095)//4096)*4096);u.mem_write(base,blob)
 stack=0x2000000;dest=0x3000000;u.mem_map(stack,0x40000);u.mem_map(dest,0x200000)
 sp=stack+0x3ff08;u.reg_write(UC_X86_REG_RSP,sp);u.mem_write(sp,(stack+0x100).to_bytes(8,'little'))
 state={'allocated':0,'entry_reached':False}
 def return_to_caller():
  rsp=u.reg_read(UC_X86_REG_RSP);ret=int.from_bytes(u.mem_read(rsp,8),'little')
  u.reg_write(UC_X86_REG_RSP,rsp+8);u.reg_write(UC_X86_REG_RIP,ret)
 def allocate(uc,addr,size,user):
  n=uc.reg_read(UC_X86_REG_RDI);assert len(expected)<=n<=0x200000
  state['allocated']=n;uc.reg_write(UC_X86_REG_RAX,dest)
  return_to_caller()
 def memcpy(uc,addr,size,user):
  a,b,n=[uc.reg_read(r) for r in [UC_X86_REG_RDI,UC_X86_REG_RSI,UC_X86_REG_RDX]]
  assert n<0x200000
  if n:uc.mem_write(a,bytes(uc.mem_read(b,n)))
  uc.reg_write(UC_X86_REG_RAX,a);return_to_caller()
 def entry(uc,addr,size,user):
  actual=bytes(uc.mem_read(dest,len(expected)))
  if actual!=expected:
   differences=[i for i,(a,b) in enumerate(zip(actual,expected)) if a!=b]
   print('DECODE DIFFERENCES',len(differences),[hex(i) for i in differences[:12]])
   (ROOT/'build/native-unpack-debug.bin').write_bytes(actual)
  assert actual==expected,'Native unpack differs'
  state['entry_reached']=True;uc.emu_stop()
 u.hook_add(UC_HOOK_CODE,allocate,begin=base+0x1ea3,end=base+0x1ea3)
 stub=stack+0x200;delta=len(blob)-e.original.FILE_SIZE
 u.mem_write(base+0x48c50+delta,stub.to_bytes(8,'little'))
 u.hook_add(UC_HOOK_CODE,memcpy,begin=stub,end=stub)
 u.hook_add(UC_HOOK_CODE,entry,begin=dest,end=dest)
 try:u.emu_start(base+0x157c,stack+0x100,count=150000000)
 except Exception:
  rsp=u.reg_read(UC_X86_REG_RSP)
  print('EMULATION FAILURE',hex(u.reg_read(UC_X86_REG_RIP)),hex(rsp),bytes(u.mem_read(rsp,16)).hex(),state)
  raise
 assert state['entry_reached'],'Unpack failed before HEN entry'
 return {'base':hex(base),'payload_sha256':hashlib.sha256(blob).hexdigest(),**state,'kernel_and_decoded_hen_executed':False}

if __name__=='__main__':
 blob=Path(sys.argv[1] if len(sys.argv)>1 else 'work/expanded-envelope-validation.bin').read_bytes()
 delta=len(blob)-e.original.FILE_SIZE;core=e.recover(blob,delta)
 results=[test(blob,core,base) for base in [0x10000000,0x910000000]]
 path=Path(sys.argv[2] if len(sys.argv)>2 else 'work/expanded-envelope-native-checks.json');path.write_text(json.dumps({'passed':len(results),'tests':results},indent=2)+'\n')
 print(json.dumps({'passed':len(results),'native_crypto_and_inflate':True,'hen_executed':False}))
