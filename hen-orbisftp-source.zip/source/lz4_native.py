"""Bounded x86-64 LZ4 block decoder for the XXFHen embedded runtime."""
SOURCE = r'''
 push rdx
 next_sequence:
 cmp rdi, rsi
 jae invalid
 movzx r8d, byte ptr [rdi]
 inc rdi
 mov r9, r8
 shr r9, 4
 cmp r9, 15
 jne literals_ready
 literals_extension:
 cmp rdi, rsi
 jae invalid
 movzx r11d, byte ptr [rdi]
 inc rdi
 add r9, r11
 jc invalid
 cmp r11, 255
 je literals_extension
 literals_ready:
 mov r11, rdi
 add r11, r9
 jc invalid
 cmp r11, rsi
 ja invalid
 mov r11, rdx
 add r11, r9
 jc invalid
 cmp r11, rcx
 ja invalid
 literal_loop:
 test r9, r9
 jz after_literals
 mov al, byte ptr [rdi]
 mov byte ptr [rdx], al
 inc rdi
 inc rdx
 dec r9
 jmp literal_loop
 after_literals:
 cmp rdi, rsi
 je finished
 mov r11, rdi
 add r11, 2
 jc invalid
 cmp r11, rsi
 ja invalid
 movzx r10d, word ptr [rdi]
 add rdi, 2
 test r10d, r10d
 jz invalid
 mov r11, rdx
 sub r11, r10
 cmp r11, qword ptr [rsp]
 jb invalid
 mov r9, r8
 and r9, 15
 add r9, 4
 mov r11, r8
 and r11, 15
 cmp r11, 15
 jne match_ready
 match_extension:
 cmp rdi, rsi
 jae invalid
 movzx r11d, byte ptr [rdi]
 inc rdi
 add r9, r11
 jc invalid
 cmp r11, 255
 je match_extension
 match_ready:
 mov r11, rdx
 add r11, r9
 jc invalid
 cmp r11, rcx
 ja invalid
 match_loop:
 test r9, r9
 jz next_sequence
 mov r11, rdx
 sub r11, r10
 mov al, byte ptr [r11]
 mov byte ptr [rdx], al
 inc rdx
 dec r9
 jmp match_loop
 finished:
 cmp rdx, rcx
 jne invalid
 mov eax, 1
 add rsp, 8
 ret
 invalid:
 xor eax, eax
 add rsp, 8
 ret
'''
