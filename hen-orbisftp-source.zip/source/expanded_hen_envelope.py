"""Relocate the original outer loader's data/BSS to enlarge its encrypted slot.

All original outer instructions remain byte-identical except RIP-relative data
displacements. Kernel routines are never executed by this builder.
"""
from pathlib import Path
import sys,struct,zlib,hashlib
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'pydeps'))
sys.path.insert(0,str(ROOT))
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86 import X86_OP_MEM,X86_REG_RIP,X86_OP_IMM
import goldhen_tool as original

def key_material(blob,delta):
 digest=original.sha256(blob[:original.PREFIX_END])
 key=bytes(a^b^c^d for a,b,c,d in zip(blob[0x48840+delta:0x48860+delta],blob[0x48860+delta:0x48880+delta],blob[0x48880+delta:0x488a0+delta],digest))
 return key,blob[original.NONCE_START+delta:original.NONCE_START+delta+12],original.sha256(key+b'GoldHEN\0')

def relocate(template,delta):
 original.require_original(template)
 assert delta>=0 and delta%4096==0
 out=bytearray(template[:original.SIZE_FIELD]+bytes(delta)+template[original.SIZE_FIELD:])
 md=Cs(CS_ARCH_X86,CS_MODE_64);md.detail=True
 instructions=list(md.disasm(template[:original.PREFIX_END],0))
 assert sum(i.size for i in instructions)==original.PREFIX_END
 changes=[]
 for i in instructions:
  for op in i.operands:
   if op.type==X86_OP_MEM and op.mem.base==X86_REG_RIP:
    target=i.address+i.size+op.mem.disp
    if target>=original.SIZE_FIELD:
     # Capstone 5 reports disp_size=2 on some 0x66-prefixed RIP operands;
     # x86-64 RIP displacement encoding is still signed 32-bit.
     assert struct.unpack_from('<i',template,i.address+i.disp_offset)[0]==op.mem.disp
     struct.pack_into('<i',out,i.address+i.disp_offset,op.mem.disp+delta)
     changes.append({'instruction':hex(i.address),'target':hex(target),'new_target':hex(target+delta)})
   if op.type==X86_OP_IMM and original.SIZE_FIELD<=op.imm<original.FILE_SIZE+0x10000:
    raise ValueError('Unexpected absolute data address requires separate relocation')
 check=list(md.disasm(out[:original.PREFIX_END],0));assert len(check)==len(instructions)
 for a,b in zip(instructions,check):
  assert (a.address,a.size,a.mnemonic)==(b.address,b.size,b.mnemonic)
  for x,y in zip(a.operands,b.operands):
   if x.type==X86_OP_MEM and x.mem.base==X86_REG_RIP:
    target=a.address+a.size+x.mem.disp
    assert y.mem.disp==x.mem.disp+(delta if target>=original.SIZE_FIELD else 0)
 # The inflater's five-entry switch table stores code offsets relative to
 # the table itself. Its data moved; its code destinations did not.
 starts={i.address for i in instructions}
 for index in range(5):
  offset=0x48320+index*4;value=struct.unpack_from('<i',template,offset)[0]
  assert 0x48320+value in starts
  struct.pack_into('<i',out,offset+delta,value-delta)
 return out,changes

def recover(blob,delta):
 expected,_=relocate((ROOT/'baseline/goldhen.bin').read_bytes(),delta)
 for a,b in [(0,original.CIPHER_START),(original.SIZE_FIELD+delta+4,original.TAG_START+delta),(original.TAG_START+delta+32,len(blob))]:
  assert blob[a:b]==expected[a:b],'Outer loader or relocated footer differs'
 assert len(blob)==original.FILE_SIZE+delta
 n=struct.unpack_from('<I',blob,original.SIZE_FIELD+delta)[0]
 assert 6<=n<=original.CAPACITY+delta
 key,nonce,auth=key_material(blob,delta)
 encrypted=blob[original.CIPHER_START:original.CIPHER_START+n]
 assert original.custom_mac(auth,nonce+encrypted)==blob[original.TAG_START+delta:original.TAG_START+delta+32]
 compressed=original.chacha20(encrypted,key,nonce)
 obj=zlib.decompressobj();core=obj.decompress(compressed)
 assert obj.eof and not obj.unused_data and len(core)==original.CORE_SIZE and len(core)<=3*n
 return core

def build(core,min_delta=0):
 assert len(core)==original.CORE_SIZE
 template=(ROOT/'baseline/goldhen.bin').read_bytes()
 from deflate_no_stored import rewrite
 compressed,deflate_report=rewrite(zlib.compress(core,9))
 delta=max(min_delta,((max(0,len(compressed)-original.CAPACITY)+4095)//4096)*4096)
 out,changes=relocate(template,delta)
 key,nonce,auth=key_material(out,delta);encrypted=original.chacha20(compressed,key,nonce)
 out[original.CIPHER_START:original.SIZE_FIELD+delta]=bytes(original.CAPACITY+delta)
 out[original.CIPHER_START:original.CIPHER_START+len(encrypted)]=encrypted
 struct.pack_into('<I',out,original.SIZE_FIELD+delta,len(encrypted))
 out[original.TAG_START+delta:original.TAG_START+delta+32]=original.custom_mac(auth,nonce+encrypted)
 result=bytes(out);assert recover(result,delta)==core
 return result,{'delta':delta,'payload_size':len(result),'compressed_size':len(compressed),'encrypted_capacity':original.CAPACITY+delta,'relocated_rip_references':changes,'deflate':deflate_report,'payload_sha256':hashlib.sha256(result).hexdigest(),'core_sha256':hashlib.sha256(core).hexdigest()}
