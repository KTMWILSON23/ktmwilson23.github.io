"""Losslessly rewrite DEFLATE stored blocks as fixed-Huffman literal blocks.

Other blocks retain their exact bits. RFC 1951 canonical Huffman coding.
"""
import zlib
class Reader:
 def __init__(self,data):self.data=data;self.bit=0
 def get(self,n):
  assert self.bit+n<=len(self.data)*8
  value=0
  for k in range(n):value|=((self.data[self.bit//8]>>(self.bit%8))&1)<<k;self.bit+=1
  return value
class Writer:
 def __init__(self):self.data=bytearray();self.bit=0
 def put(self,v,n):
  for k in range(n):
   if self.bit%8==0:self.data.append(0)
   self.data[-1]|=((v>>k)&1)<<(self.bit%8);self.bit+=1
 def copy(self,data,a,b):
  for k in range(a,b):self.put((data[k//8]>>(k%8))&1,1)
def reverse(value,width):
 result=0
 for _ in range(width):result=(result<<1)|(value&1);value>>=1
 return result
def table(lengths):
 counts=[0]*16
 for n in lengths:counts[n]+=1
 counts[0]=0;code=0;nextcode=[0]*16
 for n in range(1,16):code=(code+counts[n-1])<<1;nextcode[n]=code
 result={};encoder={}
 for symbol,n in enumerate(lengths):
  if n:
   value=reverse(nextcode[n],n);nextcode[n]+=1
   result[(value,n)]=symbol;encoder[symbol]=(value,n)
 return result,encoder
def decode(reader,t):
 value=0
 for n in range(1,16):
  value|=reader.get(1)<<(n-1)
  if (value,n) in t:return t[(value,n)]
 raise ValueError('Invalid Huffman code')
FIXED,ENCODER=table([8]*144+[9]*112+[7]*24+[8]*8)
DIST,_=table([5]*32)
LENGTH_EXTRA=[0]*8+[1]*4+[2]*4+[3]*4+[4]*4+[5]*4+[0]
def rewrite(stream):
 assert stream[0]&15==8 and not stream[1]&32
 raw=stream[2:-4];r=Reader(raw);w=Writer();types=[]
 while True:
  begin=r.bit;final=r.get(1);kind=r.get(2);types.append(kind)
  if kind==0:
   r.bit=(r.bit+7)&~7;n=r.get(16);assert r.get(16)==n^0xffff
   data=bytes(r.get(8) for _ in range(n));w.put(final,1);w.put(1,2)
   for c in data:w.put(*ENCODER[c])
   w.put(*ENCODER[256])
  elif kind in (1,2):
   if kind==1:lit,dist=FIXED,DIST
   else:
    hlit=r.get(5)+257;hdist=r.get(5)+1;hclen=r.get(4)+4
    order=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];cl=[0]*19
    for k in range(hclen):cl[order[k]]=r.get(3)
    ct,_=table(cl);lengths=[]
    while len(lengths)<hlit+hdist:
     x=decode(r,ct)
     if x<16:lengths.append(x)
     elif x==16:
      assert lengths;lengths.extend([lengths[-1]]*(r.get(2)+3))
     elif x==17:lengths.extend([0]*(r.get(3)+3))
     else:lengths.extend([0]*(r.get(7)+11))
    assert len(lengths)==hlit+hdist
    lit,_=table(lengths[:hlit]);dist,_=table(lengths[hlit:])
   while True:
    symbol=decode(r,lit)
    if symbol==256:break
    if symbol>256:
     assert 257<=symbol<=285;r.get(LENGTH_EXTRA[symbol-257])
     distance=decode(r,dist);assert distance<=29
     if distance>=4:r.get(distance//2-1)
   w.copy(raw,begin,r.bit)
  else:raise ValueError('Reserved block type')
  if final:break
 assert len(raw)*8-r.bit<8
 result=stream[:2]+bytes(w.data)+stream[-4:]
 assert zlib.decompress(result)==zlib.decompress(stream)
 return result,{'input_blocks':types,'stored_blocks_replaced':types.count(0),'input_bytes':len(stream),'output_bytes':len(result)}
