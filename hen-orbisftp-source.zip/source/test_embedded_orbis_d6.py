"""Emulate original menu dispatch plus bundled backend with virtual PS4 APIs/files."""
from pathlib import Path
import sys,json,struct,hashlib
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'pydeps'));sys.path.insert(0,str(ROOT))
import build_embedded_orbis_d6 as build
from unicorn import Uc,UC_ARCH_X86,UC_MODE_64,UC_HOOK_CODE
from unicorn.x86_const import *
payload,core,receipt,info=build.build()
elf=core[build.ELF:0x8b290]

def run(base,case):
 u=Uc(UC_ARCH_X86,UC_MODE_64);u.mem_map(base,0x100000);u.mem_write(base,elf)
 if case=='decode_corrupt':u.mem_write(base+info['bundle_offset'],b'\xff'*16)
 stack=0x2000000;heap=0x3000000;ext=0x4000000
 for addr in [stack,heap,ext]:u.mem_map(addr,0x40000)
 stop=ext+0x3ff00;alloc=heap+0x1000;records={};handlers={};files={};fdpaths={};state={'spawn_calls':0,'statuses':[],'original_press':0,'file_write_calls':0,'syscalls':[]}
 def reg(r):return u.reg_read(r)
 def q(a):return int.from_bytes(u.mem_read(a,8),'little')
 def w(a,v):u.mem_write(a,(v&0xffffffffffffffff).to_bytes(8,'little'))
 def text(a):
  b=bytearray()
  while a and len(b)<256:
   c=u.mem_read(a+len(b),1)
   if c==b'\0':break
   b.extend(c)
  return b.decode()
 def ret(v=0,carry=False):
  u.reg_write(UC_X86_REG_RAX,v&0xffffffffffffffff)
  flags=reg(UC_X86_REG_EFLAGS);u.reg_write(UC_X86_REG_EFLAGS,(flags|1) if carry else (flags&~1))
 def mock(offset,fn,absolute=False):
  a=offset if absolute else base+offset;u.mem_write(a,b'\xc3');handlers[a]=fn
 def malloc():
  nonlocal alloc
  a=alloc;alloc+=0x80;ret(a)
 mock(0x819d,malloc)
 def insert():records[text(reg(UC_X86_REG_RSI))]=reg(UC_X86_REG_RDX);ret()
 mock(0x7e37,insert)
 def klass():
  ns=text(reg(UC_X86_REG_RSI));name=text(reg(UC_X86_REG_RDX))
  assert (ns,name)==('Sce.Vsh.ShellUI.Lnc','LncUtil')
  ret(0 if case=='missing_lnc_class' else heap+0x900)
 mock(0xa67a,klass)
 appid_stub=ext+0x200
 def get_method():
  assert reg(UC_X86_REG_RSI)==heap+0x900 and text(reg(UC_X86_REG_RDX))=='GetAppId' and reg(UC_X86_REG_RCX)==1
  ret(0 if case=='missing_getappid' else appid_stub)
 mock(0xa8d6,get_method)
 def appid():assert text(reg(UC_X86_REG_RDI))=='NPXS20001';ret(0 if case=='missing_parent' else 0x10000001)
 mock(appid_stub,appid,True)
 def newstr():
  a=reg(UC_X86_REG_RDI);s=text(a)
  fail=case=='title_string_failed' and s=='NPXS20001'
  if '%08x' in s:
   formatted=(s % (reg(UC_X86_REG_RSI)&0xffffffff)).encode()+b'\0'
   u.mem_write(heap+0x20000,formatted);ret(heap+0x20000)
  else:ret(0 if fail else a)
 mock(0xa6ba,newstr)
 w(base+0x76ad0,0 if case=='missing_lnc_image' else heap+0xc00)
 def loadmodule():raise AssertionError('D6 must not load a library by filename')
 mock(0x8137,loadmodule)
 state['searched_handles']=[]
 spawn_stub=ext+0x300
 def dlsym():
  handle=reg(UC_X86_REG_RDI);assert handle in [11,12,16] and text(reg(UC_X86_REG_RSI))=='sceSystemServiceAddLocalProcess'
  state['searched_handles'].append(handle)
  found=handle==16 and case not in ['missing_spawn_symbol','symbol_lookup_failed']
  w(reg(UC_X86_REG_RDX),spawn_stub if found else 0)
  if found:ret()
  elif case=='missing_spawn_symbol':ret()
  else:ret(3,True)
 mock(0x811c,dlsym)
 def syscall():
  number=reg(UC_X86_REG_RDI);a,b,c=[reg(r) for r in [UC_X86_REG_RSI,UC_X86_REG_RDX,UC_X86_REG_RCX]]
  state['syscalls'].append(number)
  if number==97:
   assert (a,b,c)==(2,1,0);ret(13 if case=='socket_error' else 5,case=='socket_error')
  elif number==104:
   assert a==5 and c==16 and bytes(u.mem_read(b,16))==struct.pack('<QQ',0x39050210,0)
   ret(48 if case=='port_busy' else 0,case=='port_busy')
  elif number==592:
   assert b==256 and stack<=a<a+1024<stack+0x40000 and stack<=c<stack+0x40000
   if case=='module_list_failed':ret(2,True);return
   handles=[] if case=='zero_modules' else [16,11,12] if case=='first_module_success' else [11,12,16]
   for i,h in enumerate(handles):u.mem_write(a+i*4,h.to_bytes(4,'little'))
   w(c,257 if case=='oversized_module_list' else len(handles));ret()
  elif number==6:
   assert a in [5,7];ret(5 if case=='close_failed' and a==7 else 0,case=='close_failed' and a==7)
   fdpaths.pop(a,None)
  elif number==136:
   assert text(a)=='/user/data/XXFHen' and b==0x1ff
   ret()
  elif number==5:
   p=text(a);assert p in ['/user/data/XXFHen/oftp.bin','/user/data/XXFHen/jbc.sprx'] and b==0x601 and c==0x180
   if case=='open_failed':ret(13,True)
   else:files[p]=b'';fdpaths[7]=p;ret(7)
  elif number==4:
   assert a==7 and a in fdpaths;state['file_write_calls']+=1
   if case=='write_failed' and state['file_write_calls']>1:ret(5,True);return
   if case=='write_zero':ret(0);return
   if case=='write_overshoot':ret(c+1);return
   n=min(c,4096) if case in ['short_writes','write_failed'] else c
   files[fdpaths[a]]+=bytes(u.mem_read(b,n));ret(n)
  elif number==10:
   p=text(a);assert p in ['/user/data/XXFHen/oftp.bin','/user/data/XXFHen/jbc.sprx','/user/data/xxfhen-orbisftp-runtime.zip']
   files.pop(p,None);ret()
  else:raise AssertionError(('Unexpected syscall',number))
 mock(0x11772,syscall)
 def spawn():
  assert reg(UC_X86_REG_RDI)==0x10000001 and text(reg(UC_X86_REG_RSI))=='/user/data/XXFHen/oftp.bin'
  assert reg(UC_X86_REG_RDX)==0
  assert bytes(u.mem_read(reg(UC_X86_REG_RCX),40))==struct.pack('<IiiiI4xQI4x',40,-1,1,-1,0,0,0)
  assert hashlib.sha256(files['/user/data/XXFHen/oftp.bin']).hexdigest()==receipt['bundled_server_sha256']
  assert hashlib.sha256(files['/user/data/XXFHen/jbc.sprx']).hexdigest()==receipt['libjbc_sha256']
  assert b'/app0/sce_module/libjbc.sprx' not in files['/user/data/XXFHen/oftp.bin']
  state['spawn_calls']+=1;ret(0x80940001 if case=='spawn_failed' else 0 if case=='spawn_zero' else 0x60000001)
 mock(spawn_stub,spawn,True)
 element=heap+0x500;instance=heap+0x600;event=heap+0x700
 def status():
  assert reg(UC_X86_REG_RDI)==element and text(reg(UC_X86_REG_RSI))=='Value'
  state['statuses'].append(text(reg(UC_X86_REG_RDX)));ret()
 mock(0x2441d,status)
 def reset():assert text(reg(UC_X86_REG_RDI))==build.ID;ret()
 mock(0x133f8,reset)
 canaries={r:0xc0000000+i for i,r in enumerate([UC_X86_REG_RBX,UC_X86_REG_RBP,UC_X86_REG_R12,UC_X86_REG_R13,UC_X86_REG_R14,UC_X86_REG_R15])}
 def execute(addr,args):
  for r,v in canaries.items():u.reg_write(r,v)
  sp=stack+0x3ff08;w(sp,stop);u.reg_write(UC_X86_REG_RSP,sp)
  for r,v in zip([UC_X86_REG_RDI,UC_X86_REG_RSI,UC_X86_REG_RDX],args):u.reg_write(r,v)
  u.emu_start(addr,stop,count=3000000)
  assert reg(UC_X86_REG_RIP)==stop and reg(UC_X86_REG_RSP)==sp+8
  assert all(reg(r)==v for r,v in canaries.items())
 def oncode(uc,addr,size,user):
  if addr in handlers:
   assert (reg(UC_X86_REG_RSP)+8)%16==0,hex(addr)
   handlers[addr]()
 u.hook_add(UC_HOOK_CODE,oncode)
 id_old=heap+0x100;u.mem_write(id_old,b'existing_entry\0')
 execute(base+info['code'],[id_old,ext+0x800,0])
 assert set(records)=={'existing_entry',build.ID} and q(records[build.ID]+0x28)==base+info['callback']
 mock(ext+0x800,lambda:ret(),True)
 id_ptr=id_old if case=='unrelated_entry' else base+info['offsets']['id'];value=heap+0x200;u.mem_write(value,b'Ready\0')
 def prop():
  assert reg(UC_X86_REG_RDI)==element
  name=text(reg(UC_X86_REG_RSI));assert name in ['Id','Value'];ret(id_ptr if name=='Id' else value)
 mock(0x241ad,prop)
 utf=ext+0x500;mock(utf,lambda:ret(reg(UC_X86_REG_RDI)),True);w(base+0x76510,utf)
 free=ext+0x600;mock(free,lambda:ret(),True);w(base+0x764e0,free)
 def lookup():
  ptr=records.get(text(reg(UC_X86_REG_RSI)));w(reg(UC_X86_REG_RDX),ptr or 0);ret(0 if ptr else 1)
 mock(0x7f50,lookup)
 def original():
  assert (reg(UC_X86_REG_RSI),reg(UC_X86_REG_RDX),reg(UC_X86_REG_RCX))==(instance,element,event)
  state['original_press']+=1;ret()
 mock(0xf02c,original);detour=heap+0xe00;w(base+0x76c90,detour);w(detour+8,ext+0x900)
 execute(base+0x102bc,[instance,element,event])
 expected='Bundled server launch requested' if case in ['success','short_writes','first_module_success'] else 'Port 1337 is already in use' if case=='port_busy' else 'ShellUI app ID unavailable' if case=='missing_parent' else 'OF14 native file write failed' if case in ['open_failed','write_failed','write_zero','write_overshoot','close_failed'] else 'OF13 embedded block decode failed' if case=='decode_corrupt' else 'Bundled server launch failed' if case in ['spawn_failed','spawn_zero'] else 'Bundled server interface unavailable'
 if case=='spawn_failed':expected='OF12 launch error 0x80940001'
 if case=='spawn_zero':expected='OF12 launch error 0x00000000'
 if case=='zero_modules':expected='OF10 process export error 0x00000000'
 if case=='oversized_module_list':expected='OF11 module list exceeds 256 entries'
 if case=='success':assert state['searched_handles']==[11,12,16]
 if case=='first_module_success':assert state['searched_handles']==[16]
 expected={'socket_error': 'OF01 socket error 0x0000000d', 'missing_lnc_image': 'OF05 platform assembly unavailable', 'missing_lnc_class': 'OF06 LncUtil class unavailable', 'missing_getappid': 'OF07 GetAppId method unavailable', 'title_string_failed': 'OF08 title string allocation failed', 'module_list_failed': 'OF09 module list error 0x00000002', 'missing_spawn_symbol': 'OF10 process export error 0x00000000', 'symbol_lookup_failed': 'OF10 process export error 0x00000003'}.get(case,expected)
 assert state['statuses']==([] if case=='unrelated_entry' else [expected]),(case,state)
 assert state['spawn_calls']==(1 if case in ['success','short_writes','first_module_success','spawn_failed','spawn_zero'] else 0)
 assert state['original_press']==1
 assert '/user/data/xxfhen-orbisftp-runtime.zip' not in files
 if case in ['success','short_writes','first_module_success','spawn_failed','spawn_zero']:assert set(files)=={'/user/data/XXFHen/oftp.bin','/user/data/XXFHen/jbc.sprx'}
 return {'base':hex(base),'case':case,**state,'stack_and_registers_preserved':True,'installed_app_launch_called':False,'real_console_access':False}

cases=['success','short_writes','first_module_success','port_busy','socket_error','missing_lnc_image','missing_lnc_class','missing_getappid','missing_parent','module_list_failed','missing_spawn_symbol','open_failed','write_failed','write_zero','write_overshoot','close_failed','decode_corrupt','spawn_failed','spawn_zero','unrelated_entry','title_string_failed','symbol_lookup_failed','zero_modules','oversized_module_list']
results=[run(base,case) for base in [0x10000000,0x910000000] for case in cases]
report={'passed':len(results),'payload_sha256':receipt['payload_sha256'],'tests':results,'limitation':'PS4 APIs and filesystem are modeled. Does not prove live process creation, libjbc loading, FTP startup or firmware compatibility.'}
(build.OUT/'backend-emulator-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'passed':len(results),'installed_app_dependency':False,'console_executed':False}))
