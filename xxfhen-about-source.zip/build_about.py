"""Add XXFHen edition details to the existing About menu and startup notice."""

from pathlib import Path
import hashlib
import json
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
SOURCE_ROOT = ROOT.parent / "XXFHen-top-menu-logo-update"
BASE = ROOT / "baseline" / "XXFHen.bin" if (ROOT / "baseline" / "XXFHen.bin").exists() else SOURCE_ROOT / "XXFHen.bin"
TEMPLATE = ROOT / "baseline" / "goldhen.bin" if (ROOT / "baseline" / "goldhen.bin").exists() else SOURCE_ROOT / "baseline" / "goldhen.bin"
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(SOURCE_ROOT))
import goldhen_tool as tool

BASE_SHA256 = "84182cb135d3b07365691baab5c05e22e23a5c784f4ee6b585b9b6e8d635fb58"
XML_START, XML_END = 0x38AF8, 0x455FA
NOTICE_START = 0x9A622


def build():
    base = BASE.read_bytes()
    assert hashlib.sha256(base).hexdigest() == BASE_SHA256
    template = TEMPLATE.read_bytes()
    tool.require_original(template)
    core, _, _ = tool.recover(base)
    edited = bytearray(core)

    original_slot = core[XML_START:XML_END]
    original_xml = original_slot.rstrip()
    original_root = ET.fromstring(original_xml)
    assert not any((node.text or "").strip() or (node.tail or "").strip() for node in original_root.iter())

    xml = original_xml
    changes = [
        (b'<setting_list id="id_about" title="About"',
         b'<setting_list id="id_about" title="About XXFHen"'),
        (b'<setting_list id="id_about_goldhen" title="About XXFHen " icon="file://user/data/profile.dat" second_title="List of Features and Changelog of GoldHEN.">',
         b'<setting_list id="id_about_goldhen" title="XXFHen Edition" icon="file://user/data/profile.dat" second_title="XF branding, edition details and GoldHEN history.">'),
        (b'<top_label id="a1" title="GoldHEN is a payload to enable homebrew and not only!"/>',
         b'<top_label id="xxf_ed_1" title="XXFHen Personal Edition"/>'
         b'<label id="xxf_ed_2" title="By XXF Wilson" style="left" size="small"/>'
         b'<label id="xxf_ed_3" title="For PS4 firmware 14.00" style="left" size="small"/>'
         b'<label id="xxf_ed_4" title="Custom XF artwork and menu branding" style="left" size="small"/>'
         b'<label id="xxf_ed_5" title="Based on GoldHEN by SiSTRo" style="left" size="small"/>'
         b'<spacer id="xxf_ed_6" height="20"/>'
         b'<top_label id="a1" title="GoldHEN is a payload to enable homebrew and not only!"/>'),
    ]
    for old, new in changes:
        assert xml.count(old) == 1, old
        xml = xml.replace(old, new, 1)
    # The fixed XML slot was full. Remove indentation only between elements.
    # The original tree has no significant text nodes.
    compact = re.sub(rb">[ \t\r\n]+<", b"><", xml)
    assert len(compact) <= len(original_slot)
    new_root = ET.fromstring(compact)
    ids = [node.attrib["id"] for node in new_root.iter() if "id" in node.attrib]
    assert len(ids) == len(set(ids))
    assert new_root.find(".//*[@id='id_about']").attrib["title"] == "About XXFHen"
    assert new_root.find(".//*[@id='id_about_goldhen']").attrib["title"] == "XXFHen Edition"
    assert new_root.find(".//*[@id='a2']").attrib["title"] == "Coded with ❤ by SiSTRo"
    # Every existing element remains in the same order, and only its two menu titles change.
    before_ids = [node.attrib.get("id") for node in original_root.iter()]
    after_ids = [node.attrib.get("id") for node in new_root.iter() if not node.attrib.get("id", "").startswith("xxf_ed_")]
    assert before_ids == after_ids
    old_nodes = {node.attrib["id"]: node for node in original_root.iter() if "id" in node.attrib}
    new_nodes = {node.attrib["id"]: node for node in new_root.iter() if "id" in node.attrib}
    for node_id, old_node in old_nodes.items():
        new_node = new_nodes[node_id]
        expected = dict(old_node.attrib)
        if node_id == "id_about":
            expected["title"] = "About XXFHen"
        elif node_id == "id_about_goldhen":
            expected["title"] = "XXFHen Edition"
            expected["second_title"] = "XF branding, edition details and GoldHEN history."
        assert new_node.tag == old_node.tag and new_node.attrib == expected, node_id
    edited[XML_START:XML_END] = compact.ljust(len(original_slot), b" ")

    old_notice = b"XXFHen is ready!          \n"
    new_notice = b"XXFHen | XXF Wilson ready!\n"
    assert len(old_notice) == len(new_notice) == 27
    assert core[NOTICE_START:NOTICE_START + 27] == old_notice
    edited[NOTICE_START:NOTICE_START + 27] = new_notice

    allowed = set(range(XML_START, XML_END)) | set(range(NOTICE_START, NOTICE_START + 27))
    changed = [offset for offset, (a, b) in enumerate(zip(core, edited)) if a != b]
    assert changed and all(offset in allowed for offset in changed)
    payload, receipt = tool.rebuild(template, bytes(edited))
    recovered, _, _ = tool.recover(payload)
    assert recovered == bytes(edited)
    receipt.update(
        personal_revision="about-edition-4",
        base_sha256=BASE_SHA256,
        xml_slot=[hex(XML_START), hex(XML_END)],
        original_xml_bytes=len(original_xml),
        compact_xml_bytes=len(compact),
        startup_notice=new_notice.decode().strip(),
        changed_core_bytes=len(changed),
        changes_confined_to_xml_and_notice=True,
        existing_menu_ids_and_order_preserved=True,
        upstream_credit_preserved=True,
        payload_executed=False,
        console_tested=False,
    )
    return payload, receipt


if __name__ == "__main__":
    payload, receipt = build()
    ROOT.mkdir(parents=True, exist_ok=True)
    (ROOT / "XXFHen.bin").write_bytes(payload)
    (ROOT / "verification.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: receipt[key] for key in (
        "personal_revision", "payload_sha256", "payload_size", "original_xml_bytes", "compact_xml_bytes",
        "startup_notice", "changed_core_bytes")}, indent=2))
