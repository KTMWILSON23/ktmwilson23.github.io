# XXFHen About edition 4

This build starts from the XF top-menu logo edition. It changes the existing PS4
About section to **About XXFHen** and adds an edition introduction with XXF
Wilson, PS4 firmware 14.00, XF artwork, and the GoldHEN by SiSTRo attribution.
The original GoldHEN feature history and credits remain in that section.

The startup notification is `XXFHen | XXF Wilson ready!`. The existing fixed
27-byte notice slot determines the wording. The XML settings slot was full, so
the builder removes whitespace between XML tags to fit the extra labels; it
checks that every existing menu ID, element type, order, and attribute remains
the same except for the intended About titles and description. No executable
instructions, icons, or kernel patches change.

Build: `work/python312/python.exe outputs/XXFHen-about-update/build_about.py`
from the workspace root. The output is `XXFHen.bin`; `verification.json` records
hashes and structural checks. This is a binary customization, not the original
GoldHEN source. The public default launcher loads this build. The binary and menu structure pass static checks; live PS4 behavior has not yet been confirmed.
