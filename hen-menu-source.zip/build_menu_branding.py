"""Build the six-title XXFHen menu update by static processing only."""
import argparse
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import goldhen_tool as tool

BASE_PAYLOAD_SHA = '796ae39cece7c4954f1abace006f3271b69c6a1b8c8911ab47ded51a6a54d1da'
BASE_CORE_SHA = 'a8ff32b2c30224858fe59c38b16fd563c7e41f9d93fce73ee151264c16b6b4eb'
SETTINGS_START, SETTINGS_END = 0x38af8, 0x455fa
XML_REGIONS = ((SETTINGS_START, SETTINGS_END), (0x45600,0x45709), (0x45710,0x4581b))
TITLE_CHANGES = (
    ('id_goldhen_debug_settings', 'Debug Settings', 'XXFHen Tools', 0x38c28),
    ('id_goldhen_cheat_settings', 'Cheat Settings', 'XXFHen Cheats', 0x3945c),
    ('id_goldhen_plugin_settings', 'Plugin Settings', 'XXFHen Plugins', 0x39fef),
    ('id_goldhen_game_overlay', 'Game Overlay Settings', 'XXFHen Overlay', 0x3ad08),
    ('id_goldhen_servers_settings', 'Servers Settings', 'XXFHen Network', 0x3bbea),
    ('id_goldhen_utils', 'Utilities', 'XF Extras', 0x3bfda),
)


def compare_xml(before, after):
    old_nodes, new_nodes = list(ET.fromstring(before).iter()), list(ET.fromstring(after).iter())
    if len(old_nodes) != len(new_nodes):
        raise ValueError('XML node count changed')
    intended = {identifier:(old,new.ljust(len(old))) for identifier,old,new,_ in TITLE_CHANGES}
    observed = set()
    for old, new in zip(old_nodes,new_nodes):
        if old.tag != new.tag or old.text != new.text or old.tail != new.tail or old.attrib.keys() != new.attrib.keys():
            raise ValueError('XML structure/text changed')
        identifier = old.get('id')
        for key, value in old.attrib.items():
            if new.attrib[key] != value:
                if key != 'title' or identifier not in intended or (value,new.attrib[key]) != intended[identifier]:
                    raise ValueError('Unexpected XML attribute edit')
                observed.add(identifier)
    if observed != set(intended):
        raise ValueError('Missing menu title edit')


def build(base_payload, original):
    if tool.sha256(base_payload).hex() != BASE_PAYLOAD_SHA:
        raise ValueError('Use the reviewed icon-and-menu-1 XXFHen baseline')
    tool.require_original(original)
    core, _, _ = tool.recover(base_payload)
    if tool.sha256(core).hex() != BASE_CORE_SHA:
        raise ValueError('Baseline decoded core does not match')
    settings = core[SETTINGS_START:SETTINGS_END]
    ET.fromstring(settings)
    edited_xml = bytearray(settings)
    allowed, changes = set(), []
    for identifier, old_title, new_title, expected_offset in TITLE_CHANGES:
        old_bytes, new_bytes = old_title.encode('utf-8'), new_title.encode('utf-8')
        if len(new_bytes) > len(old_bytes):
            raise ValueError('Replacement exceeds the fixed title allocation')
        pattern = (rb'<setting_list\b[^>]*\bid="'+re.escape(identifier.encode())+
                   rb'"[^>]*\btitle="('+re.escape(old_bytes)+rb')"')
        matches = list(re.finditer(pattern,settings))
        if len(matches) != 1:
            raise ValueError('Expected one ID-anchored title: '+identifier)
        a,b = matches[0].span(1)
        if SETTINGS_START+a != expected_offset:
            raise ValueError('Reviewed title offset changed')
        edited_xml[a:b] = new_bytes.ljust(len(old_bytes),b' ')
        allowed.update(range(SETTINGS_START+a,SETTINGS_START+b))
        changes.append({'id':identifier,'old_title':old_title,'new_title':new_title,
                        'core_offset':hex(SETTINGS_START+a),'allocated_bytes':b-a,
                        'padding_spaces':len(old_bytes)-len(new_bytes)})
    edited_xml = bytes(edited_xml)
    if len(edited_xml) != len(settings):
        raise ValueError('XML byte count changed')
    compare_xml(settings,edited_xml)
    edited = core[:SETTINGS_START]+edited_xml+core[SETTINGS_END:]
    changed = {i for i,(a,b) in enumerate(zip(core,edited)) if a != b}
    if len(edited) != len(core) or not changed or not changed.issubset(allowed):
        raise ValueError('Core changes escaped the six title fields')
    for a,b in XML_REGIONS:
        ET.fromstring(edited[a:b])
    for a,b in ((0,0x13868),(0x69ad4,0x6cc80),(0x9a622,0x9a64d)):
        if edited[a:b] != core[a:b]:
            raise ValueError('Instructions, icon or startup notification changed')
    module_map = json.loads((ROOT/'module_map.json').read_text(encoding='utf-8'))
    protected_sections = 0
    for module in module_map['regions']:
        start,stop = int(module['core_offset'],0),int(module['end_exclusive'],0)
        if module['name'] != 'shellui_mono.elf':
            if edited[start:stop] != core[start:stop]:
                raise ValueError('Helper module changed')
        else:
            for section in module['code_sections']:
                a = start+int(section['offset'],0)
                b = a+int(section['size'],0)
                if edited[a:b] != core[a:b]:
                    raise ValueError('Executable ELF section changed')
                protected_sections += 1
    payload, receipt = tool.rebuild(original,edited)
    recovered,_,_ = tool.recover(payload)
    if recovered != edited or recovered[SETTINGS_START:SETTINGS_END] != edited_xml:
        raise ValueError('Repack/decode or re-extracted XML mismatch')
    receipt.update(personal_revision='menu-branding-2',previous_payload_sha256=BASE_PAYLOAD_SHA,
                   changes=changes,changed_core_byte_count=len(changed),
                   only_six_menu_title_fields_changed=True,xml_structure_preserved=True,
                   settings_ids_and_values_preserved=True,credits_and_paths_preserved=True,
                   icon_and_startup_preserved=True,helper_modules_unchanged=True,
                   executable_sections_unchanged=True,executable_sections_checked=protected_sections,
                   payload_executed=False,console_tested=False)
    return payload, edited_xml, receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base',type=Path,default=ROOT/'baseline/XXFHen.bin')
    parser.add_argument('--template',type=Path,default=ROOT/'baseline/goldhen.bin')
    parser.add_argument('--output',type=Path,required=True,help='New output path')
    args = parser.parse_args()
    payload, settings, receipt = build(args.base.read_bytes(),args.template.read_bytes())
    report = args.output.with_name(args.output.name+'.json')
    xml = args.output.with_name(args.output.name+'.settings.xml')
    if any(path.exists() for path in (args.output,report,xml)):
        raise ValueError('Choose new output paths; existing files are not overwritten')
    tool.write_new(args.output,payload)
    tool.write_new(report,(json.dumps(receipt,indent=2)+'\n').encode())
    tool.write_new(xml,settings)
    print(json.dumps(receipt,indent=2))


if __name__ == '__main__':
    try:
        main()
    except (ValueError,OSError) as error:
        raise SystemExit(f'Error: {error}')
