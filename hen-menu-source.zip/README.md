# XXFHen menu branding update

HEN-only candidate build, revision `menu-branding-2`, based on the existing customized GoldHEN v2.4b18.13 payload. The XF icon and startup notification remain part of this edition.

## PS4 menu wording

| Previous section | New section |
|---|---|
| Debug Settings | XXFHen Tools |
| Cheat Settings | XXFHen Cheats |
| Plugin Settings | XXFHen Plugins |
| Game Overlay Settings | XXFHen Overlay |
| Servers Settings | XXFHen Network |
| Utilities | XF Extras |

These are presentation-only section titles. Unused bytes inside each original title allocation are padded with ASCII spaces. Menu structure, settings IDs, values, resource paths, original author/supporter credits, executable sections and embedded helper modules are preserved.

## Files

- `XXFHen.bin`: the new candidate payload.
- `XXFHen.bin.json`: recorded static verification and precise title changes.
- `XXFHen.bin.settings.xml`: the re-extracted settings resource.
- `build_menu_branding.py`: Python source for the six reviewed title edits.
- `goldhen_tool.py`: static unpack/repack source used by the builder.
- `module_map.json`: protected module/code-section layout used during validation.
- `baseline/XXFHen.bin`: previous icon-and-menu-1 payload, retained for rollback and reproduction.
- `baseline/goldhen.bin`: the original user-supplied repacking template.
- `SHA256SUMS.json`: package file sizes and SHA256 hashes.

## Reproduce

Extract the entire ZIP. From the extracted directory, using Python 3.10+:

```sh
python build_menu_branding.py --output rebuilt/XXFHen.bin
```

Only the Python standard library is required. Outputs must be new paths. The script never executes the HEN payload. It validates the exact baseline hashes, byte allocations, six-field XML diff, settings IDs, protected code/modules, authentication, and repack/decode equality.

This package contains the source for these binary customizations. GoldHEN's original buildable source was not recovered. Static checks passed; the new candidate has not been tested on a PS4. It has not been substituted into either published webhost, and it does not resolve the separately reported console connection error.
