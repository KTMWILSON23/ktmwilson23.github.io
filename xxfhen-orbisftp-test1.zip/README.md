# XXFHen Network / OrbisFTP experimental build 1

Adds **XXFHen Network > Start OrbisFTP**. It targets your existing installation, OFTP00001. No installer is included or run.

This is an experimental native binary patch, not a recovered original GoldHEN source build. The action has NOT been executed on the PS4. It can fail or crash ShellUI; keep the rollback payload available. The normal public launcher is unchanged.

## Console test

1. Fully restart the PS4 (not Rest Mode); a running HEN may skip reinstallation.
2. Load XXFHen-OrbisFTP-TEST.bin with your existing compatible loader, or use the dedicated test link supplied separately.
3. Open XXFHen > XXFHen Network > Start OrbisFTP.
4. If OrbisFTP is already running, the menu should show `Already running`. Otherwise it should show `Launch requested` after the launch service accepts the request. `Launch failed` or `Launch interface unavailable` identifies a failure; neither message claims FTP is running.
5. Confirm you can connect to OrbisFTP on its usual port. For a rollback, fully restart and load XXFHen-rollback.bin or use the regular host.

The running daemon was present during inspection. Testing an actual new start requires a later fresh boot where OrbisFTP is not already running; this build does not stop or restart it.

## Checks

24 x86-64 emulation checks passed across two relocation bases. These execute the existing registration routine and OnPress dispatcher, covering new launches, already running, launch errors, missing methods, allocation failure and unrelated entries. They check stack alignment and preserved registers. PS4 Mono/LncUtil calls are mocked, so this is not a live compatibility test.

The console's actual menu assembly metadata confirms the method signatures and packed 24-byte launch parameter layout. PNG pixels/palette and the top-menu DDS are unchanged; the new code occupies an existing private PNG ancillary padding chunk with an updated CRC, within the ELF's existing RX segment. Only one existing CALL instruction changes. Menu XML gains one button; existing menu semantics, module layout and other core components are preserved. Repack authentication and decode comparison pass.

## Rebuild

Use Python 3, install source/requirements.txt, then run source/build_orbis_network.py and source/test_orbis_network.py. Output is source/build/. The included baselines are checked by SHA-256. callback.asm is a readable assembly listing. The source ZIP contains our patch builder and tests, not original GoldHEN C/C++ source or Sony console assemblies.

GoldHEN by SiSTRo and original contributors; existing credits remain intact. OrbisFTP by OSM-Made. Interface references: https://github.com/OSM-Made/OrbisFTP and https://github.com/OSM-Made/Orbis-Toolbox . No upstream C++ implementation was copied into this patch.
