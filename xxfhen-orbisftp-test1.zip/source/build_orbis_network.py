"""Experimental fixed-layout XXFHen menu callback patch. Does not execute PS4 code."""
from pathlib import Path
import sys,struct,json,hashlib,zlib,re,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'pydeps'))
sys.path.insert(0,str(ROOT))
from keystone import Ks,KS_ARCH_X86,KS_MODE_64
import goldhen_tool as tool

BASE_SHA='84182cb135d3b07365691baab5c05e22e23a5c784f4ee6b585b9b6e8d635fb58'
ELF=0x13868
PNG_A,PNG_B=0x69ad4,0x6cc7c
XML_A,XML_B=0x38af8,0x455fa
HOOK=0x9da0
ID='id_xxfhen_start_orbisftp'
OUT=ROOT/'build'
ks=Ks(KS_ARCH_X86,KS_MODE_64)

def assemble(src,addr):return bytes(ks.asm(src,addr)[0])
def call(addr):return f'lea rax, [rbx + {addr}]; call rax'
def png_chunks(data):
 p=8
 while p<len(data):
  n=struct.unpack_from('>I',data,p)[0];kind=data[p+4:p+8]
  assert zlib.crc32(data[p+4:p+8+n])&0xffffffff==struct.unpack_from('>I',data,p+8+n)[0]
  yield p,n,kind
  p+=n+12
 assert p==len(data)

def build(base,template):
 assert hashlib.sha256(base).hexdigest()==BASE_SHA,'Unexpected baseline'
 tool.require_original(template)
 core,_,_=tool.recover(base); edited=bytearray(core)
 old_png=core[PNG_A:PNG_B]
 padding=[(p,n) for p,n,k in png_chunks(old_png) if k==b'xxFh']
 assert len(padding)==1
 p,n=padding[0]; assert old_png[p+8:p+8+n]==bytes(n)
 cave=PNG_A+p+8-ELF
 # Place strings after a bounded code area, entirely inside the existing private PNG chunk.
 STRINGS={
  'id':ID,'namespace':'Sce.Vsh.ShellUI.Lnc','klass':'LncUtil',
  'init':'LaunchAppParamInit','launch':'LaunchApp','appid':'GetAppId','titleid':'OFTP00001',
  'value':'Value','running':'Already running',
  'requested':'Launch requested','failed':'Launch failed',
  'unsupported':'Launch interface unavailable',
 }
 code_reserve=800; offsets={};string_bytes=bytearray()
 for key,value in STRINGS.items():
  offsets[key]=cave+code_reserve+len(string_bytes);string_bytes.extend(value.encode()+b'\0')
 assert code_reserve+len(string_bytes)<=n
 def lea(reg,key):return f'lea {reg}, [rbx + {offsets[key]}]'
 # The first registration remains unchanged; append our own no-data button callback.
 wrapper=f'''
  .byte 0xf3,0x0f,0x1e,0xfa
  push rbx
  lea rbx, [rip]
  sub rbx, {cave+12}
  {call(0x9d30)}
  {lea('rdi','id')}
  lea rsi, [rbx + {cave+128}]
  xor edx, edx
  xor ecx, ecx
  {call(0x9d30)}
  pop rbx
  ret
 '''
 wrapper_bytes=assemble(wrapper,cave); assert len(wrapper_bytes)<=128
 callback=cave+128
 body=f'''
  .byte 0xf3,0x0f,0x1e,0xfa
  push rbx
  push rbp
  push r12
  push r13
  push r14
  push r15
  sub rsp, 0x48
  lea rbx, [rip]
  sub rbx, {callback+25}
  mov r12, rsi
  mov rdi, [rbx + 0x76ad0]
  test rdi, rdi
  jz unavailable
  {lea('rsi','namespace')}
  {lea('rdx','klass')}
  {call(0xa67a)}
  test rax, rax
  jz unavailable
  mov rbp, rax
  mov rdi, [rbx + 0x76ad0]
  mov rsi, rbp
  {lea('rdx','init')}
  mov ecx, 1
  {call(0xa8d6)}
  test rax, rax
  jz unavailable
  mov r15, rax
  mov rdi, [rbx + 0x76ad0]
  mov rsi, rbp
  {lea('rdx','launch')}
  mov ecx, 4
  {call(0xa8d6)}
  test rax, rax
  jz unavailable
  mov [rsp + 0x20], rax
  mov rdi, [rbx + 0x76ad0]
  mov rsi, rbp
  {lea('rdx','appid')}
  mov ecx, 1
  {call(0xa8d6)}
  test rax, rax
  jz unavailable
  mov r13, rax
  {lea('rdi','titleid')}
  xor eax, eax
  {call(0xa6ba)}
  test rax, rax
  jz unavailable
  mov r14, rax
  mov rdi, r14
  call r13
  test eax, eax
  jg already_running
  xor eax, eax
  mov [rsp], rax
  mov [rsp + 8], rax
  mov [rsp + 16], rax
  mov rdi, rsp
  call r15
  mov dword ptr [rsp + 4], -1
  call qword ptr [rbx + 0x76530]
  test rax, rax
  jz unavailable
  mov rdi, rax
  xor esi, esi
  {call(0xa8be)}
  test rax, rax
  jz unavailable
  mov rsi, rax
  mov rdi, r14
  xor edx, edx
  mov rcx, rsp
  call qword ptr [rsp + 0x20]
  test eax, eax
  js launch_failed
  {lea('rdi','requested')}
  jmp status
 already_running:
  {lea('rdi','running')}
  jmp status
 launch_failed:
  {lea('rdi','failed')}
  jmp status
 unavailable:
  {lea('rdi','unsupported')}
 status:
  xor eax, eax
  {call(0xa6ba)}
  mov rdx, rax
  mov rdi, r12
  {lea('rsi','value')}
  {call(0x2441d)}
  {lea('rdi','id')}
  {call(0x133f8)}
  add rsp, 0x48
  pop r15
  pop r14
  pop r13
  pop r12
  pop rbp
  pop rbx
  ret
 '''
 body_bytes=assemble(body,callback)
 # The base calculations above are checked instruction-by-instruction in the emulator.
 assert 128+len(body_bytes)<=code_reserve
 blob=wrapper_bytes.ljust(128,b'\x90')+body_bytes
 blob=blob.ljust(code_reserve,b'\0')+string_bytes
 new_png=bytearray(old_png);new_png[p+8:p+8+len(blob)]=blob
 struct.pack_into('>I',new_png,p+8+n,zlib.crc32(new_png[p+4:p+8+n])&0xffffffff)
 list(png_chunks(new_png));edited[PNG_A:PNG_B]=new_png
 assert core[ELF+HOOK:ELF+HOOK+5]==assemble('call 0x9d30',HOOK)
 edited[ELF+HOOK:ELF+HOOK+5]=assemble(f'call {cave}',HOOK)
 old_xml=core[XML_A:XML_B]
 needle=b'      <toggle_switch id="id_goldhen_toggle_ftp"'
 assert old_xml.count(needle)==1
 button=(f'      <button id="{ID}" title="Start OrbisFTP" value="Ready" '
  'second_title="Open your installed OrbisFTP. Experimental launcher; no installer." '
  'icon="file://user/data/profile.dat"/>\r\n').encode()
 new_xml=old_xml.replace(needle,button+needle)
 new_xml=re.sub(rb'(?m)^ +',b'',new_xml)
 assert len(new_xml)<=len(old_xml)
 new_xml=new_xml.rstrip()+b' '*(len(old_xml)-len(new_xml.rstrip()))
 before=ET.fromstring(old_xml);after=ET.fromstring(new_xml)
 network=next(x for x in after.iter() if x.get('id')=='id_goldhen_servers_settings')
 added=next(x for x in network if x.get('id')==ID);network.remove(added)
 def canonical(x):return (x.tag,x.attrib,(x.text or '').strip(),tuple(canonical(c) for c in x))
 assert canonical(before)==canonical(after),'Existing menu semantics changed'
 assert added.tag=='button' and added.get('title')=='Start OrbisFTP'
 edited[XML_A:XML_B]=new_xml
 allowed=set(range(XML_A,XML_B))|set(range(PNG_A+p+8,PNG_A+p+8+n+4))|set(range(ELF+HOOK,ELF+HOOK+5))
 changed=[i for i,(a,b) in enumerate(zip(core,edited)) if a!=b]
 assert all(i in allowed for i in changed)
 payload,receipt=tool.rebuild(template,bytes(edited))
 recovered,_,_=tool.recover(payload);assert recovered==edited
 receipt.update(personal_revision='orbisftp-network-experimental-1',console_tested=False,
  baseline_sha256=BASE_SHA,installed_title_id='OFTP00001',installer_included=False,
  hook_elf_offset=hex(HOOK),code_elf_offset=hex(cave),callback_elf_offset=hex(callback),
  wrapper_bytes=len(wrapper_bytes),callback_bytes=len(body_bytes),chunk_payload_bytes=n,
  changed_core_bytes=len(changed),existing_menu_semantics_preserved=True,
  code_placement='Existing zero-filled private ancillary PNG chunk in RX PT_LOAD segment; PNG CRC updated',
  elf_layout_unchanged=True,code_scope='One registration CALL plus new callback in PNG private ancillary data',
  ps4_files_written=False,public_host_changed=False)
 return payload,receipt,{'cave':cave,'callback':callback,'offsets':offsets,'assembly':wrapper+'\n\n'+body,'edited_core':bytes(edited)}

if __name__=='__main__':
 payload,receipt,info=build((ROOT/'baseline/XXFHen.bin').read_bytes(),(ROOT/'baseline/goldhen.bin').read_bytes())
 OUT.mkdir(exist_ok=True)
 (OUT/'XXFHen-OrbisFTP-TEST.bin').write_bytes(payload)
 (OUT/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
 (OUT/'callback.asm').write_text(info['assembly'])
 (ROOT/'build/patch-info.json').write_text(json.dumps({k:v for k,v in info.items() if k not in ['assembly','edited_core']},indent=2))
 print(json.dumps(receipt,indent=2))
