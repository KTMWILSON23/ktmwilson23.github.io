const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const html = fs.readFileSync('work/github-pages/repository/orbis.html','utf8');
const script = html.match(/<script>([\s\S]*?)<\/script>/)[1];
new vm.Script(script);
const cases = [
  {name:'desktop',ua:'Desktop browser',allowed:false},
  {name:'other firmware',ua:'PlayStation 4/13.00',allowed:false},
  {name:'ready',ua:'PlayStation 4/14.00',allowed:true},
  {name:'offline',ua:'PlayStation 4/14.00',allowed:true,offline:true},
  {name:'storage failure',ua:'PlayStation 4/14.00',allowed:true,storageError:true}
];
for (const c of cases) {
  const nodes={};let submit;
  for (const id of ['start','hint','console-status','console-dot','start-label','launch-form']) nodes[id]={disabled:id==='start',textContent:'',className:'',addEventListener:(name,fn)=>{if(name==='submit')submit=fn;}};
  const context={navigator:{userAgent:c.ua,onLine:!c.offline},document:{getElementById:id=>nodes[id]},sessionStorage:{setItem:(k,v)=>{assert.equal(k,'xxfhen.activation');if(c.storageError)throw new Error('unavailable');}},Date,location:{href:''}};
  vm.runInNewContext(script,context);
  assert.equal(nodes.start.disabled,!c.allowed);
  assert.equal(context.location.href,''); // Opening the page never launches anything.
  submit({preventDefault(){}});
  assert.equal(context.location.href,c.allowed&&!c.offline&&!c.storageError?'jb.html?log=1&afterglow=run&mode=goldhen&payload=xxfhen-orbisftp-test1.bin':'');
}
fs.writeFileSync('outputs/XXFHen-OrbisFTP-experimental/launcher-checks.json',JSON.stringify({passed:cases.length,cases:cases.map(x=>x.name),exploit_executed:false},null,2)+'\n');
console.log(`${cases.length} launcher checks passed`);
