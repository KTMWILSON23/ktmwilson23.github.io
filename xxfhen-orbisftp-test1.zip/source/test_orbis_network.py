"""Emulate the patched registration + original OnPress dispatcher; PS4 APIs are mocked."""
import sys,json,struct,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'pydeps'));sys.path.insert(0,str(ROOT))
import build_orbis_network as build
from unicorn import Uc,UC_ARCH_X86,UC_MODE_64,UC_HOOK_CODE
from unicorn.x86_const import *
payload,receipt,info=build.build((ROOT/'baseline/XXFHen.bin').read_bytes(),(ROOT/'baseline/goldhen.bin').read_bytes())
elf=info['edited_core'][build.ELF:0x8b290]

def run(base,case):
 u=Uc(UC_ARCH_X86,UC_MODE_64);u.mem_map(base,0x100000);u.mem_write(base,elf)
 stack=0x2000000;u.mem_map(stack,0x20000)
 heap=0x3000000;u.mem_map(heap,0x20000)
 external=0x4000000;u.mem_map(external,0x10000)
 stop=external+0xff00;alloc=heap+0x1000;records={};calls=[];state={'launches':0,'statuses':[],'original_press':0}
 def q(addr):return struct.unpack('<Q',bytes(u.mem_read(addr,8)))[0]
 def w(addr,val):u.mem_write(addr,struct.pack('<Q',val&0xffffffffffffffff))
 def s(addr):
  out=bytearray()
  while addr and len(out)<512:
   c=u.mem_read(addr+len(out),1)
   if c==b'\0':break
   out.extend(c)
  return out.decode()
 def reg(r):return u.reg_read(r)
 def ret(v=0):u.reg_write(UC_X86_REG_RAX,v&0xffffffffffffffff)
 handlers={}
 def mock(offset,fn,abs=False):
  addr=offset if abs else base+offset;u.mem_write(addr,b'\xc3');handlers[addr]=fn
 def malloc():
  nonlocal alloc
  a=alloc;alloc+=0x80;ret(a)
 def insert():
  records[s(reg(UC_X86_REG_RSI))]=reg(UC_X86_REG_RDX);ret()
 mock(0x819d,malloc);mock(0x7e37,insert)
 def klass():
  assert s(reg(UC_X86_REG_RSI))=='Sce.Vsh.ShellUI.Lnc'
  assert s(reg(UC_X86_REG_RDX))=='LncUtil'
  ret(0 if case=='missing_class' else heap+0x800)
 mock(0xa67a,klass)
 method_ptrs={k:external+0x100+i*0x100 for i,k in enumerate(['LaunchAppParamInit','LaunchApp','GetAppId'])}
 def method():
  name=s(reg(UC_X86_REG_RDX));count=reg(UC_X86_REG_RCX)
  assert count=={'LaunchAppParamInit':1,'LaunchApp':4,'GetAppId':1}[name]
  ret(0 if case=='missing_'+name else method_ptrs[name])
 mock(0xa8d6,method)
 def newstr():
  arg=reg(UC_X86_REG_RDI)
  ret(0 if case=='title_allocation_failed' and s(arg)=='OFTP00001' else arg)
 mock(0xa6ba,newstr)
 def appid():
  assert s(reg(UC_X86_REG_RDI))=='OFTP00001';ret(0x60000101 if case=='already_running' else 0)
 mock(method_ptrs['GetAppId'],appid,True)
 def init():
  addr=reg(UC_X86_REG_RDI);u.mem_write(addr,struct.pack('<IiiiQ',24,0,0,0,0));ret()
 mock(method_ptrs['LaunchAppParamInit'],init,True)
 def launch():
  assert s(reg(UC_X86_REG_RDI))=='OFTP00001'
  assert reg(UC_X86_REG_RSI)==heap+0xa00 and reg(UC_X86_REG_RDX)==0
  params=bytes(u.mem_read(reg(UC_X86_REG_RCX),24))
  assert struct.unpack('<IiiiQ',params)==(24,-1,0,0,0)
  state['launches']+=1;ret(0x80940001 if case=='launch_error' else 0x60000101)
 mock(method_ptrs['LaunchApp'],launch,True)
 byteclass=external+0x500
 mock(byteclass,lambda:ret(0 if case=='missing_byte_class' else heap+0x900),True);w(base+0x76530,byteclass)
 def array():
  assert reg(UC_X86_REG_RDI)==heap+0x900 and reg(UC_X86_REG_RSI)==0
  ret(0 if case=='array_allocation_failed' else heap+0xa00)
 mock(0xa8be,array)
 element=heap+0x500;instance=heap+0x600;event=heap+0x700
 def status():
  assert reg(UC_X86_REG_RDI)==element and s(reg(UC_X86_REG_RSI))=='Value'
  state['statuses'].append(s(reg(UC_X86_REG_RDX)));ret()
 mock(0x2441d,status)
 def reset():assert s(reg(UC_X86_REG_RDI))==build.ID;ret()
 mock(0x133f8,reset)
 w(base+0x76ad0,0 if case=='missing_image' else heap+0xb00)
 # Original registration and original OnPress are executed, not replaced by test models.
 canaries={r:0xc0000000+i for i,r in enumerate([UC_X86_REG_RBX,UC_X86_REG_RBP,UC_X86_REG_R12,UC_X86_REG_R13,UC_X86_REG_R14,UC_X86_REG_R15])}
 def execute(addr,args):
  for r,v in canaries.items():u.reg_write(r,v)
  sp=stack+0x1ff08;w(sp,stop);u.reg_write(UC_X86_REG_RSP,sp)
  for r,v in zip([UC_X86_REG_RDI,UC_X86_REG_RSI,UC_X86_REG_RDX,UC_X86_REG_RCX],args):u.reg_write(r,v)
  u.emu_start(addr,stop,count=15000)
  assert reg(UC_X86_REG_RIP)==stop,'Did not return'
  assert reg(UC_X86_REG_RSP)==sp+8,'Unbalanced stack'
  assert all(reg(r)==v for r,v in canaries.items()),'Clobbered nonvolatile register'
 def oncode(uc,addr,size,user):
  if addr in handlers:
   assert (reg(UC_X86_REG_RSP)+8)%16==0, f'Misaligned external call at {hex(addr)}'
   calls.append(hex(addr-base));handlers[addr]()
 u.hook_add(UC_HOOK_CODE,oncode)
 id_old=heap+0x100;u.mem_write(id_old,b'existing_entry\0')
 execute(base+info['cave'],[id_old,external+0x800,0,0])
 assert len(records)==2 and 'existing_entry' in records and build.ID in records
 record=records[build.ID]
 assert struct.unpack('<I',u.mem_read(record,4))[0]==0 and q(record+0x28)==base+info['callback']
 id_ptr=id_old if case=='unrelated_entry' else base+info['offsets']['id'];value_ptr=heap+0x200;u.mem_write(value_ptr,b'Ready\0')
 mock(external+0x800,lambda:ret(),True)
 def prop():
  assert reg(UC_X86_REG_RDI)==element
  name=s(reg(UC_X86_REG_RSI));assert name in ['Id','Value'];ret(id_ptr if name=='Id' else value_ptr)
 mock(0x241ad,prop)
 string_to_utf8=external+0x600;mock(string_to_utf8,lambda:ret(reg(UC_X86_REG_RDI)),True);w(base+0x76510,string_to_utf8)
 free=external+0x700;mock(free,lambda:ret(),True);w(base+0x764e0,free)
 def lookup():
  ptr=records.get(s(reg(UC_X86_REG_RSI)));w(reg(UC_X86_REG_RDX),ptr or 0);ret(0 if ptr else 1)
 mock(0x7f50,lookup)
 def original_press():
  assert reg(UC_X86_REG_RSI)==instance and reg(UC_X86_REG_RDX)==element and reg(UC_X86_REG_RCX)==event
  state['original_press']+=1;ret()
 mock(0xf02c,original_press)
 detour=heap+0xc00;w(base+0x76c90,detour);w(detour+8,external+0x900)
 execute(base+0x102bc,[instance,element,event])
 expected='Already running' if case=='already_running' else 'Launch failed' if case=='launch_error' else 'Launch requested' if case=='success' else 'Launch interface unavailable'
 assert state['statuses']==([] if case=='unrelated_entry' else [expected]),state
 assert state['launches']==(1 if case in ['success','launch_error'] else 0),state
 assert state['original_press']==1
 return {'base':hex(base),'case':case,**state,'stack_and_nonvolatile_registers_preserved':True,'original_dispatcher_and_registration_executed':True}

cases=['success','already_running','launch_error','missing_image','missing_class','missing_LaunchAppParamInit','missing_LaunchApp','missing_GetAppId','title_allocation_failed','missing_byte_class','array_allocation_failed','unrelated_entry']
results=[run(base,case) for base in [0x10000000,0x910000000] for case in cases]
report={'payload_sha256':hashlib.sha256(payload).hexdigest(),'tests':results,'passed':len(results),'ps4_execution':False,'limitation':'Mocked PS4 Mono/LncUtil APIs; verifies x86-64 code/dispatch/ABI, not live console compatibility.'}
(build.OUT/'emulator-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'passed':len(results),'payload_sha256':report['payload_sha256']}))
