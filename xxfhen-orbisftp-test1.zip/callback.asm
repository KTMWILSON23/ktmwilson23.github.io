
  .byte 0xf3,0x0f,0x1e,0xfa
  push rbx
  lea rbx, [rip]
  sub rbx, 364479
  lea rax, [rbx + 40240]; call rax
  lea rdi, [rbx + 365267]
  lea rsi, [rbx + 364595]
  xor edx, edx
  xor ecx, ecx
  lea rax, [rbx + 40240]; call rax
  pop rbx
  ret
 


  .byte 0xf3,0x0f,0x1e,0xfa
  push rbx
  push rbp
  push r12
  push r13
  push r14
  push r15
  sub rsp, 0x48
  lea rbx, [rip]
  sub rbx, 364620
  mov r12, rsi
  mov rdi, [rbx + 0x76ad0]
  test rdi, rdi
  jz unavailable
  lea rsi, [rbx + 365292]
  lea rdx, [rbx + 365312]
  lea rax, [rbx + 42618]; call rax
  test rax, rax
  jz unavailable
  mov rbp, rax
  mov rdi, [rbx + 0x76ad0]
  mov rsi, rbp
  lea rdx, [rbx + 365320]
  mov ecx, 1
  lea rax, [rbx + 43222]; call rax
  test rax, rax
  jz unavailable
  mov r15, rax
  mov rdi, [rbx + 0x76ad0]
  mov rsi, rbp
  lea rdx, [rbx + 365339]
  mov ecx, 4
  lea rax, [rbx + 43222]; call rax
  test rax, rax
  jz unavailable
  mov [rsp + 0x20], rax
  mov rdi, [rbx + 0x76ad0]
  mov rsi, rbp
  lea rdx, [rbx + 365349]
  mov ecx, 1
  lea rax, [rbx + 43222]; call rax
  test rax, rax
  jz unavailable
  mov r13, rax
  lea rdi, [rbx + 365358]
  xor eax, eax
  lea rax, [rbx + 42682]; call rax
  test rax, rax
  jz unavailable
  mov r14, rax
  mov rdi, r14
  call r13
  test eax, eax
  jg already_running
  xor eax, eax
  mov [rsp], rax
  mov [rsp + 8], rax
  mov [rsp + 16], rax
  mov rdi, rsp
  call r15
  mov dword ptr [rsp + 4], -1
  call qword ptr [rbx + 0x76530]
  test rax, rax
  jz unavailable
  mov rdi, rax
  xor esi, esi
  lea rax, [rbx + 43198]; call rax
  test rax, rax
  jz unavailable
  mov rsi, rax
  mov rdi, r14
  xor edx, edx
  mov rcx, rsp
  call qword ptr [rsp + 0x20]
  test eax, eax
  js launch_failed
  lea rdi, [rbx + 365390]
  jmp status
 already_running:
  lea rdi, [rbx + 365374]
  jmp status
 launch_failed:
  lea rdi, [rbx + 365407]
  jmp status
 unavailable:
  lea rdi, [rbx + 365421]
 status:
  xor eax, eax
  lea rax, [rbx + 42682]; call rax
  mov rdx, rax
  mov rdi, r12
  lea rsi, [rbx + 365368]
  lea rax, [rbx + 148509]; call rax
  lea rdi, [rbx + 365267]
  lea rax, [rbx + 78840]; call rax
  add rsp, 0x48
  pop r15
  pop r14
  pop r13
  pop r12
  pop rbp
  pop rbx
  ret
 